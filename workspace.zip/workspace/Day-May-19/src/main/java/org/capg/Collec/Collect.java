package org.capg.Collec;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.ListIterator;

public class Collect 
{
	public static void main(String[] args) 
	{
		ArrayList l1 = new ArrayList();
		int[] i1 = {0,1,2,3,4};
		ArrayList l2 = new ArrayList();
		ArrayList l3 = new ArrayList();
		
		
		
		l2.add(99);
		l2.add(88);
			
		l1.add(5);
		l1.add(6);
		l1.add(7);
		l1.add(8);
	
		l1.addAll(l2);
		
		l1.trimToSize();
		l1.ensureCapacity(0);		
		
		System.out.println(l3.isEmpty());
		
		System.out.println(l1.iterator());
		
		System.out.println(l1.containsAll(l2));
		
		
		
		System.out.println(l1.contains(99));
		l1.remove(5);
		
		l1.set(2, 565);
		
		l1.removeAll(l2);
		System.out.println(l1);
		l1.addAll(l2);
		
		System.out.println(l1);
		
		System.out.println(l1.get(3));
		
		System.out.println(l1.indexOf(6));
		
		System.out.println(l1.size());
		
		System.out.println(l1.lastIndexOf(8));
	
				{
			
				};
		
				
		System.out.println(l1.listIterator());
		
		System.out.println(l1.subList(1, 5));
		
		l1.toArray();
		
		l1.clear();
	}
}
