package org.capg.Collec;

import java.util.LinkedList;

public class LinkedListDemo 
{
public static void main(String[] args)
{
	LinkedList l1 = new LinkedList();
	l1.add("Rajatha");
	l1.add(11);
	l1.add(22);
	l1.add(33);
	l1.add(44);
	l1.add(55);
	
	
}
}
