package org.capg.Collec;

public class Employ33 implements Comparable<Employ33>
{
	private int eId;
	private String fName;
	private String lName;
	private double sal;
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public Employ33(int eId, String fName, String lName, double sal) {
		super();
		this.eId = eId;
		this.fName = fName;
		this.lName = lName;
		this.sal = sal;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public Employ33() 
	{
		
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employ33 [eId=" + eId + ", fName=" + fName + ", lName=" + lName + ", sal=" + sal + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + eId;
		result = prime * result + ((fName == null) ? 0 : fName.hashCode());
		result = prime * result + ((lName == null) ? 0 : lName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(sal);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employ33 other = (Employ33) obj;
		if (eId != other.eId)
			return false;
		if (fName == null) {
			if (other.fName != null)
				return false;
		} else if (!fName.equals(other.fName))
			return false;
		if (lName == null) {
			if (other.lName != null)
				return false;
		} else if (!lName.equals(other.lName))
			return false;
		if (Double.doubleToLongBits(sal) != Double.doubleToLongBits(other.sal))
			return false;
		return true;
	}
	public int compareTo(Employ33 emp) 
	{
		/*if(this.geteId()>emp.geteId())
			return 1;
		else if (this.geteId()< emp.geteId())
			return -1;
		else
		return 0;*/
		
		if(this.getfName().compareTo(emp.getfName())>0)
			return 1;
		if(this.getfName().compareTo(emp.getfName())<0)
			return -1;
		else
			return 0;
	}
	
	
	
}
