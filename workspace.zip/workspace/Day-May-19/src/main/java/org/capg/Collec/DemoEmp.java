package org.capg.Collec;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class DemoEmp 
{
	public static void main(String[] args) 
	{
		Employ33 e1 = new Employ33(1,"tom","jerry", 23000.00);
		Employ33 e2 = new Employ33(2,"Mickey","Mouse", 254000.00);
		Employ33 e3 = new Employ33(3,"Scooby","Doo", 26000.00);
		Employ33 e4 = new Employ33(4,"Donald","Duck", 560.00);
		Employ33 e5 = new Employ33(5,"Bugs","Bunny", 7590.00);
		Employ33 e6 = new Employ33(4,"Donald","Duck", 560.00);
		Employ33 e7 = new Employ33(2,"Mickey","Mouse", 254000.00);
		
		//HashSet<Employ33> emp = new HashSet<Employ33>();
		//LinkedHashSet<Employ33> emp = new LinkedHashSet<Employ33>();
		
		TreeSet<Employ33> emp = new TreeSet<Employ33>();
		
		
		
		emp.add(e1);
		emp.add(e2);
		emp.add(e3);
		emp.add(e4);
		emp.add(e5);
		emp.add(e6);
		emp.add(e7);
		
		
		Iterator<Employ33> it = emp.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
}
