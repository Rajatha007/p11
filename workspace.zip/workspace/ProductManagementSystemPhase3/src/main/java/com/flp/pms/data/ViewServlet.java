package com.flp.pms.data;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplforMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Product;
import com.google.gson.Gson;

public class ViewServlet extends  HttpServlet
{
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		
		PrintWriter out=response.getWriter();
			
	IProductDao iProductDao=new ProductDaoImplforMap();
		
		List<Product> product=iProductDao.viewAllProducts();
		
			Gson myJson=new Gson();
		
		String productjson=myJson.toJson(product);		
		    out.println(productjson);
}
}

