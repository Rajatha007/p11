package com.flp.pms.data;

import com.flp.pms.domain.Category;

public class PojoClass 
{
private String pName;
private Category cName;
private int qty;
private double sal;


public PojoClass() {
	super();
}


public PojoClass(String pName, Category cName, int qty, double sal) {
	super();
	this.pName = pName;
	this.cName = cName;
	this.qty = qty;
	this.sal = sal;
}


public String getpName() {
	return pName;
}


public void setpName(String pName) {
	this.pName = pName;
}


public Category getcName() {
	return cName;
}


public void setcName(Category cName) {
	this.cName = cName;
}


public int getQty() {
	return qty;
}


public void setQty(int qty) {
	this.qty = qty;
}


public double getSal() {
	return sal;
}


public void setSal(double sal) {
	this.sal = sal;
}


@Override
public String toString() {
	return "PojoClass [pName=" + pName + ", cName=" + cName + ", qty=" + qty + ", sal=" + sal + "]";
}



}
