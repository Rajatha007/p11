package org.cap.Multithreadingdemo;

import java.util.Scanner;

public class Account 
{
	
			private double balance=500;
			
			synchronized public void withdraw()
			{				
				if(this.balance<500){
					System.out.println("Insufficient Balance!Waiting for produced...");
					
						try {
							wait();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
			
			System.out.println("Enter the amount to withdraw");
			Scanner scn = new Scanner(System.in);
			double withdraw = scn.nextDouble();
				
			if ((balance-withdraw)>=500)
			{
				System.out.println("Insufficient Balance!Waiting for produced...");
				
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				balance = balance-withdraw;
				System.out.println("Transaction complete the balance is" + balance);
				notifyAll();
			}
				
				
			}
			
			
			synchronized public void deposit()
			{
				System.out.println("Enter the amount to deposit");
				Scanner scn = new Scanner(System.in);
				double deposit = scn.nextDouble();
				balance = balance+deposit;
				System.out.println("Transaction complete the balance is" + balance);
				
				notifyAll();
				
			}
	 }



