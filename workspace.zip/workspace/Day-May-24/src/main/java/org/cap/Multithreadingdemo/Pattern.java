package org.cap.Multithreadingdemo;

public class Pattern extends Thread
{
	public static void main(String[] args) {
		
		
		{
			Runnable runnable=new Runnable() {
				
				public void run() 
				{
					String name = "Capgemini";
					
					
					for(int i=0;i<=name.length()-1;i++)
					{
						for (int j=0;j<=i;j++)
						{
				
					System.out.print(name.charAt(j));
				
					}
						System.out.println();
					}
					System.out.println("------------------------------------------------------------------------");
					
				}
			};
			
		Runnable runnable1=new Runnable() {
				
			public void run() 
			{
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String name = "Realistic";
				
				
				for(int i=0;i<=name.length()-1;i++)
				{
					for (int j=0;j<=i;j++)
					{
			
				System.out.print(name.charAt(j));
			
				}
					System.out.println();
				}
				System.out.println("------------------------------------------------------------------------");
				
			}
		};
			
		Runnable runnable2=new Runnable() {
				
			public void run() 
			{
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String name = "Rajatha";
				
				
				for(int i=0;i<=name.length()-1;i++)
				{
					for (int j=0;j<=i;j++)
					{
			
				System.out.print(name.charAt(j));
			
				}
					System.out.println();
				}
				System.out.println("------------------------------------------------------------------------");
				
			}
		};
	
			
			Thread t1=new Thread(runnable,"first");
			t1.start();
			t1.setPriority(MAX_PRIORITY);
			
			Thread t2=new Thread(runnable1,"second");
			t2.start();
			t2.setPriority(MIN_PRIORITY);

			Thread t3=new Thread(runnable2,"third");
			t3.start();
			t3.setPriority(NORM_PRIORITY);
		}
		}
}
