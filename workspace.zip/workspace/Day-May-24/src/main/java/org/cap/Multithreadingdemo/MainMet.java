package org.cap.Multithreadingdemo;

public class MainMet
{
public static void main(String[] args) {
	final Account account=new Account();
	
	Thread t1=new Thread(){
		@Override
		public void run(){
			account.withdraw();
		}
	};
	
	Thread t2=new Thread(){
		@Override
		public void run(){
			account.produceProduct(10);
		}
	};
	
	Thread t3=new Thread(){
		@Override
		public void run(){
			account.consumeProduct(7);
		}
	};
	
	Thread t4=new Thread(){
		@Override
		public void run(){
			account.consumeProduct(10);
		}
	};
	
	
	t1.start();
	t2.start();
	t3.start();
	t4.start();

}
}
}
