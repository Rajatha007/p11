package org.cap.Multithreadingdemo;

import java.util.ArrayList;

public class PrimeFibanocci
{
	int i = 0;
	int j = 1;
	public void getFibanocciSeries()
	{
		ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(0);
		arr.add(1);
		for(int n=2;n<10000;++n)
		{
			int l=i+j;
			i=j;
			j=l;
			arr.add(l);
	}
		System.out.println(arr);
}
	
	public void getPrimeNumbers()
	{
		ArrayList<Integer> arr1 = new ArrayList<Integer>();
		  
        for(int i=1; i < 100; i++)
        {             
                for(int j=2; j < i ; j++){
                       
                        if(i % j != 0)
                        {
                        	 arr1.add(i);
                   
                        }
                       
                        System.out.println(arr1);
               
                }
}}
	
	public static void main(String[] args)
	{
		PrimeFibanocci f1 = new PrimeFibanocci();
		f1.getFibanocciSeries();
		f1.getPrimeNumbers();
	}
}
