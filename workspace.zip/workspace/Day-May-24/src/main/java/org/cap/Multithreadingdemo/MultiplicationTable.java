package org.cap.Multithreadingdemo;

public class MultiplicationTable extends Thread
{
	public static void main(String[] args) throws InterruptedException {
		
	
{
	Runnable runnable=new Runnable() {
		
		public void run() {
			
			for(int i=1;i<=20;i++)
				System.out.println( Thread.currentThread().getName()+"-->"+"5*"+i + "=" +(i*5));
			System.out.println("------------------------------------------------------------------------");
			
		}
	};
	
Runnable runnable1=new Runnable() {
		
		public void run() {
		//	try {
				//Thread.sleep(1000);
			//} catch (InterruptedException e) {
				// TODO Auto-generated catch block
		//		e.printStackTrace();
	//		}
			for(int i=1;i<=20;i++)
				System.out.println( Thread.currentThread().getName()+"-->"+"10*"+i + "=" +(i*10));
			System.out.println("------------------------------------------------------------------------");
		}
	};
	
Runnable runnable2=new Runnable() {
		
		public void run() {
	//		try {
				//Thread.sleep(2000);
		//	} catch (InterruptedException e) {
				// TODO Auto-generated catch block
		//		e.printStackTrace();
		//	}
			for(int i=1;i<=20;i++)
				System.out.println( Thread.currentThread().getName()+"-->"+"15*"+i + "=" +(i*15));
			System.out.println("------------------------------------------------------------------------");
		}
	};
	
	Thread t1=new Thread(runnable,"first");
	t1.setPriority(MAX_PRIORITY);
	t1.start();
	
	
	
	Thread t2=new Thread(runnable1,"second");
	t2.setPriority(MIN_PRIORITY);
	t2.start();


	Thread t3=new Thread(runnable2,"third");
	t3.setPriority(MIN_PRIORITY);
	t3.start();
	
}
}
}
