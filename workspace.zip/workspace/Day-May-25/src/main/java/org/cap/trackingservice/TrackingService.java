package org.cap.trackingservice;

import java.util.ArrayList;
import java.util.List;

public class TrackingService 
{
private int id;
private int total;
private int goal;
private List<Product> products = new ArrayList<Product>();
private int itrmHistory=0;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getTotal() {
	return total;
}
public void setTotal(int total) {
	this.total = total;
}
public int getGoal() {
	return goal;
}
public void setGoal(int goal) {
	this.goal = goal;
}
public List<Product> getProducts() {
	return products;
}
public void setProducts(List<Product> products) {
	this.products = products;
}
public int getItrmHistory() {
	return itrmHistory;
}
public void setItrmHistory(int itrmHistory) {
	this.itrmHistory = itrmHistory;
}

public void produceProduct(int amount)
{
	total+= amount;
	products.add(new Product(itrmHistory, amount, total, "produce"));
	
	
}
public void consumeProduct(int amount)
{
	total-= amount;
	if(total<0)
		total = 0;
	products.add(new Product(itrmHistory, amount, total, "consume"));
	
	
}
}
