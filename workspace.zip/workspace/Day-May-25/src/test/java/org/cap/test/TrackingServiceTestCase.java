package org.cap.test;

import static org.junit.Assert.*;

import org.cap.trackingservice.TrackingService;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class TrackingServiceTestCase {

	TrackingService service = new TrackingService();
	@BeforeClass
	public static void setUp()
	{
		System.out.println("Class loaded with supporting instance");
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("Class objects destroyed after completion");
	}
	@Test
	public void whenIncreaseProductIncreaseTotal()
	{
		service.produceProduct(10);
		
		assertEquals(10, service.getTotal());
	}
	
	@Test
	public void whenDecreseProductIncreaseTotal()
	{
		service.consumeProduct(5);
		
		assertEquals(0, service.getTotal());
	}
}
