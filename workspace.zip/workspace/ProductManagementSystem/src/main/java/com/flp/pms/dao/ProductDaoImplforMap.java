package com.flp.pms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;
import com.flp.pms.view.BootClass;
import com.flp.pms.view.UserInteraction;

public class ProductDaoImplforMap implements IProductDao {

	public static Map<Integer, Product> products = new HashMap<Integer, Product>();

	/*
	 * public List<Category> getAllCategory() { List<Category> categories = new
	 * ArrayList<Category>(); categories.add(new Category(1, "Electronics",
	 * "Electronic Items")); categories.add(new Category(2, "Clothing",
	 * "All Cloth Varity")); categories.add(new Category(3, "Health&Care",
	 * "Health And Hospitality")); categories.add(new Category(4, "HouseHolds",
	 * "HouseHold Items")); categories.add(new Category(5, "Sports",
	 * "Games related Items"));
	 * 
	 * return categories; }
	 * 
	 * public List<Sub_Category> getAllSubCategory() { List<Sub_Category>
	 * subcategories=new ArrayList<Sub_Category>(); subcategories.add(new
	 * Sub_Category(101, "Mobile",new Category(1, "Electronics",
	 * "Electronic Items"))); subcategories.add(new Sub_Category(102,
	 * "PowerBank",new Category(1, "Electronics", "Electronic Items")));
	 * subcategories.add(new Sub_Category(103, "Data Storage",new Category(1,
	 * "Electronics", "Electronic Items")));
	 * 
	 * 
	 * subcategories.add(new Sub_Category(201, "T-Shirt",new Category(2,
	 * "Clothing", "All Cloth Varity"))); subcategories.add(new
	 * Sub_Category(202, "Kurta",new Category(2, "Clothing", "All Cloth Varity"
	 * ))); subcategories.add(new Sub_Category(203, "Saree",new Category(2,
	 * "Clothing", "All Cloth Varity"))); subcategories.add(new
	 * Sub_Category(204, "Kids Wear",new Category(2, "Clothing",
	 * "All Cloth Varity")));
	 * 
	 * subcategories.add(new Sub_Category(301,"Diabetic Shoes",new Category(3,
	 * "Health&Care", "Health And Hospitality"))); subcategories.add(new
	 * Sub_Category(302,"Diabetic Metre",new Category(3, "Health&Care",
	 * "Health And Hospitality"))); subcategories.add(new Sub_Category(303,
	 * "Blood Pressure Metre",new Category(3, "Health&Care",
	 * "Health And Hospitality")));
	 * 
	 * 
	 * subcategories.add(new Sub_Category(401,"Dining Sets", new Category(4,
	 * "HouseHolds", "HouseHold Items"))); subcategories.add(new
	 * Sub_Category(402,"Cooker", new Category(4, "HouseHolds",
	 * "HouseHold Items"))); subcategories.add(new Sub_Category(403,"Knife", new
	 * Category(4, "HouseHolds", "HouseHold Items"))); subcategories.add(new
	 * Sub_Category(404,"Glasses", new Category(4, "HouseHolds",
	 * "HouseHold Items")));
	 * 
	 * 
	 * subcategories.add(new Sub_Category(501, "Cricket Bat", new Category(5,
	 * "Sports", "Games related Items"))); subcategories.add(new
	 * Sub_Category(502, "Cricket Ball", new Category(5, "Sports",
	 * "Games related Items"))); subcategories.add(new Sub_Category(503,
	 * "Hockey bat", new Category(5, "Sports", "Games related Items")));
	 * subcategories.add(new Sub_Category(504, "Hockey Ball", new Category(5,
	 * "Sports", "Games related Items"))); subcategories.add(new
	 * Sub_Category(505, "Volley Ball", new Category(5, "Sports",
	 * "Games related Items")));
	 * 
	 * return subcategories;
	 * 
	 * }
	 * 
	 * public List<Supplier> getAllSuppliers() { List<Supplier> suppliers=new
	 * ArrayList<Supplier>(); suppliers.add(new Supplier(111, "Tom", "Jerry",
	 * "North Avvenue", "Chennai", "Tamil Nadu", "600041", "6576575012"));
	 * suppliers.add(new Supplier(222, "Jack", "Thomson", "South Avvenue",
	 * "Chennai", "Tamil Nadu", "600341", "7898797856")); suppliers.add(new
	 * Supplier(333, "Kamal", "Emi", "West Avvenue", "Chennai", "Tamil Nadu",
	 * "600001", "7876657655")); suppliers.add(new Supplier(444, "Annie",
	 * "Kenn", "EAST Avvenue", "Pune", "Maharastra", "600121", "5464565645"));
	 * suppliers.add(new Supplier(555, "Vimal", "Desai", "7th Avvenue", "Pune",
	 * "Maharastra", "600121", "8768678745")); suppliers.add(new Supplier(666,
	 * "Bimal", "Singh", "12th Avvenue", "Pune", "Maharastra", "600121",
	 * "1245676745")); return suppliers;
	 * 
	 * }
	 * 
	 * public List<Discount> getAllDiscounts() { List<Discount> discounts=new
	 * ArrayList<Discount>(); discounts.add(new Discount(123, "Mega Offer",
	 * "Mega offer From Jan to Feb", 12.4, new Date(2009-1900, 4, 23)));
	 * discounts.add(new Discount(333, "Dewali Offer", "Dewali offer ", 12.4,
	 * new Date(2018-1900, 4, 23))); discounts.add(new Discount(678,
	 * "New Year Offer", "New Year offer ", .50, new Date(2020-1900, 4, 23)));
	 * discounts.add(new Discount(1234, "X'Mas Offer", "Xmas offer ", .55, new
	 * Date(2019-1900, 4, 23))); discounts.add(new Discount(340, "Pongal Offer",
	 * "Pongal offer ", 12.78, new Date(2017-1900, 4, 23)));
	 * 
	 * 
	 * return discounts; }
	 */

	public Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectflp", "root", "india123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	public Statement getStatement() {

		Connection con = getConnection();
		Statement stmt = null;
		
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return stmt;

	}

	public List<Category> getAllCategory() {
		List<Category> categories = new ArrayList<Category>();
			
		{
			Statement stmt = getStatement();
			ResultSet rs = null;

			try {
					rs = stmt.executeQuery("select * from category");

				while (rs.next()) {
					Category category = new Category();
					category.setCategory_Id(rs.getInt("categoryid"));
					category.setCategory_Name(rs.getString("categoryname"));
					category.setDiscription(rs.getString("description"));
					categories.add(category);

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				closeConnection();
			}
			
		}
		return categories;
	}

	public List<Sub_Category> getAllSubCategory() {
		List<Sub_Category> subcategories = new ArrayList<Sub_Category>();
		List<Category> categories = getAllCategory();
		Category category = null;
		Sub_Category subcategory = null;
		{
			ResultSet rs = null;
			Statement stmt = getStatement();
			try {
				rs = stmt.executeQuery("select * from subcategory");

				while (rs.next()) {
					subcategory = new Sub_Category();
					subcategory.setSub_Category_Id(rs.getInt(1));
					subcategory.setSub_Category_Name(rs.getString(2));
					int category_Id = rs.getInt(3);
					for (Category Category2 : categories) {
						if (Category2.getCategory_Id() == category_Id) {
							  category=Category2;
							break;
						}
					}
					subcategory.setCategory_Id(category);
					subcategories.add(subcategory);
				}
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				closeConnection();
			}
			
		}
		return subcategories;      
	}

		public List<Supplier> getAllSuppliers() {
		List<Supplier> suppliers = new ArrayList<Supplier>();

		{
			Statement stmt = getStatement();
			ResultSet rs = null;
			
			try {
				rs = stmt.executeQuery("select * from supplier");

				while (rs.next()) {
					Supplier supplier = new Supplier();
					supplier.setSupplier_Id(rs.getInt(1));
					supplier.setFirst_Name(rs.getString(2));
					supplier.setLast_Name(rs.getString(3));
					supplier.setAddress(rs.getString(4));
					supplier.setCity(rs.getString(5));
					supplier.setPinCode(rs.getString(6));
					supplier.setContactNo(rs.getString(7));

					suppliers.add(supplier);

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				closeConnection();
			}
			

		}
		return suppliers;

	}

	public List<Discount> getAllDiscounts() {
		List<Discount> discount = new ArrayList<Discount>();
		{
			Statement stmt = getStatement();
			ResultSet rs = null;
			try {
				rs = stmt.executeQuery("select * from discount");
				while (rs.next()) {
			
				Discount discounts = new Discount();
				discounts.setDiscount_Id(rs.getInt(1));
				discounts.setDiscount_Name(rs.getString(2));
				discounts.setDescription(rs.getString(3));
				discounts.setDiscount_percentage(rs.getDouble(4));
				java.util.Date newDate = rs.getTimestamp(5);
				discounts.setValidThru(newDate);
					
				discount.add(discounts);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				closeConnection();
			}

		return discount;
		}
	}

	/*
	 * public void addProduct(Product product) {
	 * products.putIfAbsent(product.getProduct_Id(), product); }
	 */

	public void addProduct(Product product) {
		
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		PreparedStatement pstmt3 = null;
		ResultSet rs = null;
		String qry = "INSERT INTO product (productname, description, manufactrdate,expirydate,maxretailprice,category_id,subcategoryid,supplier_id,quantity,ratings) values (?, ?, ?, ?,?,?,?,?,?,?)";

		try {
			pstmt = getConnection().prepareStatement(qry);

			pstmt.setString(1, product.getProduct_Name());
			pstmt.setString(2, product.getDiscription());

			java.util.Date manufactureDate = new java.util.Date();
			java.sql.Date sqlDate = new java.sql.Date(manufactureDate.getTime());

			pstmt.setDate(3, sqlDate);

			java.util.Date expiryDate = new java.util.Date();
			java.sql.Date sqlExDate = new java.sql.Date(expiryDate.getTime());

			pstmt.setDate(4, sqlExDate);

			pstmt.setDouble(5, product.getMax_Retail_Prices());
			pstmt.setInt(6, product.getCategory().getCategory_Id());
			pstmt.setInt(7, product.getSub_Category().getSub_Category_Id());
			pstmt.setInt(8, product.getSupplier().getSupplier_Id());
			pstmt.setInt(9, product.getQuantity());
			pstmt.setFloat(10, product.getRatings());
			
			pstmt.executeUpdate();
			
			String query2 = "select * from product";
			
			pstmt2 = getConnection().prepareStatement(query2);

			rs = pstmt2.executeQuery();

			int id =0;
			while (rs.next()) 
			{
				id = rs.getInt(1);
			}

			String query3 = "INSERT INTO product_discount values(?,?)";
	    	pstmt3 = getConnection().prepareStatement(query3);

			List<Discount> discnt = product.getDiscount();
			for (Discount d : discnt) {

				pstmt3.setInt(1, id);
				pstmt3.setInt(2, d.getDiscount_Id());
				pstmt3.executeUpdate();
			}

	/*		if (rowsInserted > 0) {
				System.out.println("A new user was inserted successfully!");
			}*/

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			closeConnection();
		}
		
	}
	
	public List<Product> viewAllProducts()
	{
		List<Product> view = new ArrayList<Product>();
		ResultSet rs = null;
		Statement stmt = getStatement();
		Category category = null;
		Sub_Category subcategory = null;
		Supplier supplier = null;
		PreparedStatement pstmt = null;
		ResultSet rs1=null;
		
		try {
			rs = stmt.executeQuery("select * from product");
			while(rs.next())
			{
				Product product = new Product();
				
				product.setProduct_Id(rs.getInt(1));
				product.setProduct_Name(rs.getString(2));
				product.setDiscription(rs.getString(3));
				java.util.Date manufacturingDate = rs.getTimestamp(4);
				product.setManufacturing_Date(manufacturingDate);
				
				java.util.Date expiryDate = rs.getTimestamp(5);
				product.setExpiry_Date(expiryDate);
				
				product.setMax_Retail_Prices(rs.getDouble(6));
				
				int categoryId = rs.getInt(7);
				List<Category> cat=getAllCategory();
				for (Category c : cat)
					if (c.getCategory_Id() == categoryId)
				product.setCategory(c);
				
				int subCategoryId = rs.getInt(8);
				for (Sub_Category sc : getAllSubCategory())
					if (sc.getSub_Category_Id() == subCategoryId)
						subcategory = sc;
				product.setSub_Category(subcategory);
				
				int supplierId = rs.getInt(9);
				
				for (Supplier sup : getAllSuppliers())
					if (sup.getSupplier_Id() == supplierId)
						supplier = sup;
				product.setSupplier(supplier);
				
				product.setQuantity(rs.getInt(10));
				
				product.setRatings(rs.getFloat(11));

				pstmt = getConnection().prepareStatement("select * from product_discount where product_id=?");
				pstmt.setInt(1, product.getProduct_Id());
				rs1 = pstmt.executeQuery();
				Discount d = null;
				List<Discount> discounts2 = null;
				while (rs1.next()) {
				discounts2 = new ArrayList<>();
					int dId = rs1.getInt(2);
					for (Discount discount : getAllDiscounts())
						if (dId == discount.getDiscount_Id())
							d = discount;

					discounts2.add(d);
				}
				product.setDiscount(discounts2);
				view.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			closeConnection();
		}
	
		return view;
		
	}
	public boolean removeProduct(int productid) 
	{
		boolean flag = false;
		PreparedStatement pstmt1 = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		try {
			pstmt2 = getConnection().prepareStatement("delete  from product where productId=?");
			pstmt2.setInt(1,productid);
			pstmt2.execute();
			pstmt1 = getConnection().prepareStatement("delete from product_discount where product_id=?");
			pstmt1.setInt(1,productid);
			 pstmt1.execute();
			flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			closeConnection();
		}
		return flag;
		
	}

	public void closeConnection()  
	{
		
       if(getConnection()!=null)
       {
    	   try {
    		  getConnection().close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       }	
    }
	
	  public ArrayList<Product> searchByProductName()
      {
		 ArrayList<Product> list = new ArrayList<>();
		  List<Product> lst = viewAllProducts();
		  for(Product list1 : lst)
		  {
			  if(list1.getProduct_Name().equalsIgnoreCase(UserInteraction.productName))
			  {
				  list.add(list1);
			  }
		  }
		 
		return list;
      }
	  
	  public ArrayList<Product> searchBySupplierName()
	  {
		  ArrayList<Product> list = new ArrayList<>();
		  List<Product> lst = viewAllProducts();
		  for(Product list1 : lst)
		  {
			  if(list1.getSupplier().getFirst_Name().equalsIgnoreCase(UserInteraction.supplierName))
			  {
				  list.add(list1);
			  }
		  }
		 
		return list;
	  }
	  
		public void searchByCategoryName(String categoryName) 
		{
			List<Product> product = viewAllProducts();
			List<Product> product1 = new ArrayList<>();
			for (Product products : product)
				if (products.getCategory().getCategory_Name().equalsIgnoreCase(categoryName))
					product1.add(products);
			System.out.println(product1);
		}
		
		

		public ArrayList<Product> searchByRatings()
		{
			ArrayList<Product> list = new ArrayList<>();
			  List<Product> lst = viewAllProducts();
			  for(Product list1 : lst)
			  {
				  if(list1.getRatings() == UserInteraction.ratings)
				  {
					  list.add(list1);
				  }
			  }
			return list;
		}
		
		

	public Map<Integer, Product> getAllProducts() {

		return products;

	}

	@Override
	public void updateProductName(int productId, Product p, String pName)
	{
		PreparedStatement pstmt = null;
		  try {
			pstmt = getConnection().prepareStatement("update product set productname=? where productId = ?");
			pstmt.setString(1, pName);
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
	}

	@Override
	public void updateRetailPrice(int productId, Product p, double price) {
		PreparedStatement pstmt = null;
		  try {
			pstmt = getConnection().prepareStatement("update product set maxretailprice=? where productId = ?");
			pstmt.setDouble(1, price);
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
		
	}

	@Override
	public void updateExpiryDate(int productId, Product p, java.util.Date date) {
		PreparedStatement pstmt = null;
		  try {
			     date = new java.util.Date();
				java.sql.Date sqlExDate = new java.sql.Date(date.getTime());
			pstmt = getConnection().prepareStatement("update product set expirydate=? where productId = ?");
			pstmt.setDate(1, sqlExDate);
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
	}

	@Override
	public void updateRating(int productId, Product p, float ratings)
	{
		PreparedStatement pstmt = null;
		  try {
			    
			pstmt = getConnection().prepareStatement("update product set ratings=? where productId = ?");
			pstmt.setFloat(1, ratings);
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
		
	}

	@Override
	public void updateCategory(int productId, Product p, Category category) 
	{
		PreparedStatement pstmt = null;
		  try {
	    
			pstmt = getConnection().prepareStatement("update product set category_id=? where productId = ?");
			
			pstmt.setInt(1,category.getCategory_Id() );
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
	}

	@Override
	public void searchBySubCategory(String scategoryName) {
		List<Product> product = viewAllProducts();
		List<Product> product1 = new ArrayList<>();
		for (Product products : product)
			if (products.getSub_Category().getSub_Category_Name().equalsIgnoreCase(scategoryName))
				product1.add(products);
		System.out.println(product1);
		
	}

	




	





}
