package com.flp.pms.util;

import java.util.Date;
import com.flp.pms.domain.Product;

public class Validate 
{
	public static boolean isValidProductName(String productName)
	{
		return productName.matches("[A-Z][A-Za-z1-9_$\\s]*");
	}
	
	public static boolean isValidDate(String givenDate)
	{
		
		return givenDate.matches("([0][1-9]|[1-2]\\d{1}|[30|31])-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][7890]\\d{2}");
		
	}
	public static boolean isValidexpiryDate(Date expiryDate)
	{
		Date date1 = new Date();		
		return expiryDate.after(date1);
	
	}
	
	public static boolean isValidRating(float ratings)
	{
		if(ratings>0.0f && ratings<5.0)
		{
			return true;
		}
		else
			return false;
	}
	
	public static boolean isValidQuantity(int quantity)
	{
		return quantity>0;
	}
	
	public static boolean isValidContactNo(String contactNo)
	{
		return contactNo.matches("//d{10}");
	}
	
}
