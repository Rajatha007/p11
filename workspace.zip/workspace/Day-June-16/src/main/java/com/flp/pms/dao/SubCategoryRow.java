package com.flp.pms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Sub_Category;

public class SubCategoryRow implements RowMapper<Sub_Category>
{
	IProductDao iproduct = new ProductDaoImplforMap();

	public Sub_Category mapRow(ResultSet rs, int count) throws SQLException 
	{
		Category category = null;
		List<Category> categories = iproduct.getAllCategory();
		Sub_Category subcategory = new Sub_Category();
		subcategory.setSub_Category_Id(rs.getInt(1));
		subcategory.setSub_Category_Name(rs.getString(2));
		int category_Id = rs.getInt(3);
		for (Category Category2 : categories) {
			if (Category2.getCategory_Id() == category_Id) {
				  category=Category2;
				break;
			}
		}
		subcategory.setCategory_Id(category);

		return subcategory;
	}

}
