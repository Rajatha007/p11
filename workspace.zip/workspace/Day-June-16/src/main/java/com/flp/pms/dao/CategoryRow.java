package com.flp.pms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.flp.pms.domain.Category;

public class CategoryRow implements RowMapper<Category>
{
	public Category mapRow(ResultSet rs, int count) throws SQLException
	{
		Category category = new Category();
		category.setCategory_Id(rs.getInt("categoryid"));
		category.setCategory_Name(rs.getString("categoryname"));
		category.setDiscription(rs.getString("description"));
		return category;
		
	}
}
