package com.flp.pms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;
import com.flp.pms.view.BootClass;
import com.flp.pms.view.UserInteraction;

public class ProductDaoImplforMap implements IProductDao
{
	public static Map<Integer, Product> products = new HashMap<Integer, Product>();
 
	private JdbcTemplate jdbcTemp;
    private DataSource dataSource;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemp=new JdbcTemplate(dataSource);
	}

	/*public Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectflp", "root", "india123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	public Statement getStatement() {

		Connection con = getConnection();
		Statement stmt = null;
		
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return stmt;

	}*/

	public List<Category> getAllCategory()
	{
		String sql = 	"select * from category";
		
		List<Category>  categories = jdbcTemp.query(sql, new CategoryRow());
		return categories;
	}
					



	public List<Sub_Category> getAllSubCategory()
	{
		List<Sub_Category> subcategories = new ArrayList<Sub_Category>();
		
			String sql = "select * from subcategory";

				
		return subcategories;      
	}

		public List<Supplier> getAllSuppliers() {
		List<Supplier> suppliers = new ArrayList<Supplier>();

		{
			Statement stmt = getStatement();
			ResultSet rs = null;
			
			try {
				rs = stmt.executeQuery("select * from supplier");

				while (rs.next()) {
					Supplier supplier = new Supplier();
					supplier.setSupplier_Id(rs.getInt(1));
					supplier.setFirst_Name(rs.getString(2));
					supplier.setLast_Name(rs.getString(3));
					supplier.setAddress(rs.getString(4));
					supplier.setCity(rs.getString(5));
					supplier.setPinCode(rs.getString(6));
					supplier.setContactNo(rs.getString(7));

					suppliers.add(supplier);

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				closeConnection();
			}
			

		}
		return suppliers;

	}

	public List<Discount> getAllDiscounts() {
		List<Discount> discount = new ArrayList<Discount>();
		{
			Statement stmt = getStatement();
			ResultSet rs = null;
			try {
				rs = stmt.executeQuery("select * from discount");
				while (rs.next()) {
			
				Discount discounts = new Discount();
				discounts.setDiscount_Id(rs.getInt(1));
				discounts.setDiscount_Name(rs.getString(2));
				discounts.setDescription(rs.getString(3));
				discounts.setDiscount_percentage(rs.getDouble(4));
				java.util.Date newDate = rs.getTimestamp(5);
				discounts.setValidThru(newDate);
					
				discount.add(discounts);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				closeConnection();
			}

		return discount;
		}
	}

	/*
	 * public void addProduct(Product product) {
	 * products.putIfAbsent(product.getProduct_Id(), product); }
	 */

	public void addProduct(Product product) {
		
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		PreparedStatement pstmt3 = null;
		ResultSet rs = null;
		String qry = "INSERT INTO product (productname, description, manufactrdate,expirydate,maxretailprice,category_id,subcategoryid,supplier_id,quantity,ratings) values (?, ?, ?, ?,?,?,?,?,?,?)";

		try {
			pstmt = getConnection().prepareStatement(qry);

			pstmt.setString(1, product.getProduct_Name());
			pstmt.setString(2, product.getDiscription());

			java.util.Date manufactureDate = new java.util.Date();
			java.sql.Date sqlDate = new java.sql.Date(manufactureDate.getTime());

			pstmt.setDate(3, sqlDate);

			java.util.Date expiryDate = new java.util.Date();
			java.sql.Date sqlExDate = new java.sql.Date(expiryDate.getTime());

			pstmt.setDate(4, sqlExDate);

			pstmt.setDouble(5, product.getMax_Retail_Prices());
			pstmt.setInt(6, product.getCategory().getCategory_Id());
			pstmt.setInt(7, product.getSub_Category().getSub_Category_Id());
			pstmt.setInt(8, product.getSupplier().getSupplier_Id());
			pstmt.setInt(9, product.getQuantity());
			pstmt.setFloat(10, product.getRatings());
			
			pstmt.executeUpdate();
			
			String query2 = "select * from product";
			
			pstmt2 = getConnection().prepareStatement(query2);

			rs = pstmt2.executeQuery();

			int id =0;
			while (rs.next()) 
			{
				id = rs.getInt(1);
			}

			String query3 = "INSERT INTO product_discount values(?,?)";
	    	pstmt3 = getConnection().prepareStatement(query3);

			List<Discount> discnt = product.getDiscount();
			for (Discount d : discnt) {

				pstmt3.setInt(1, id);
				pstmt3.setInt(2, d.getDiscount_Id());
				pstmt3.executeUpdate();
			}

	/*		if (rowsInserted > 0) {
				System.out.println("A new user was inserted successfully!");
			}*/

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			closeConnection();
		}
		
	}
	
	public List<Product> viewAllProducts()
	{
		List<Product> view = new ArrayList<Product>();
		ResultSet rs = null;
		Statement stmt = getStatement();
		Category category = null;
		Sub_Category subcategory = null;
		Supplier supplier = null;
		PreparedStatement pstmt = null;
		ResultSet rs1=null;
		
		try {
			rs = stmt.executeQuery("select * from product");
			while(rs.next())
			{
				Product product = new Product();
				
				product.setProduct_Id(rs.getInt(1));
				product.setProduct_Name(rs.getString(2));
				product.setDiscription(rs.getString(3));
				java.util.Date manufacturingDate = rs.getTimestamp(4);
				product.setManufacturing_Date(manufacturingDate);
				
				java.util.Date expiryDate = rs.getTimestamp(5);
				product.setExpiry_Date(expiryDate);
				
				product.setMax_Retail_Prices(rs.getDouble(6));
				
				int categoryId = rs.getInt(7);
				
				for (Category c : getAllCategory())
					if (c.getCategory_Id() == categoryId)
				product.setCategory(category);
				
				int subCategoryId = rs.getInt(8);
				for (Sub_Category sc : getAllSubCategory())
					if (sc.getSub_Category_Id() == subCategoryId)
						subcategory = sc;
				product.setSub_Category(subcategory);
				
				int supplierId = rs.getInt(9);
				
				for (Supplier sup : getAllSuppliers())
					if (sup.getSupplier_Id() == supplierId)
						supplier = sup;
				product.setSupplier(supplier);
				
				product.setQuantity(rs.getInt(10));
				
				product.setRatings(rs.getFloat(11));

				pstmt = getConnection().prepareStatement("select * from product_discount where product_id=?");
				pstmt.setInt(1, product.getProduct_Id());
				rs1 = pstmt.executeQuery();
				Discount d = null;
				List<Discount> discounts2 = null;
				while (rs1.next()) {
				discounts2 = new ArrayList<>();
					int dId = rs1.getInt(2);
					for (Discount discount : getAllDiscounts())
						if (dId == discount.getDiscount_Id())
							d = discount;

					discounts2.add(d);
				}
				product.setDiscount(discounts2);
				view.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			closeConnection();
		}
	
		return view;
		
	}
	public boolean removeProduct(int productid) 
	{
		boolean flag = false;
		PreparedStatement pstmt1 = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		try {
			pstmt2 = getConnection().prepareStatement("delete  from product where productId=?");
			pstmt2.setInt(1,productid);
			pstmt2.execute();
			pstmt1 = getConnection().prepareStatement("delete from product_discount where product_id=?");
			pstmt1.setInt(1,productid);
			 pstmt1.execute();
			flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			closeConnection();
		}
		return flag;
		
	}

	public void closeConnection()  
	{
		
       if(getConnection()!=null)
       {
    	   try {
    		  getConnection().close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       }	
    }
	
	  public ArrayList<Product> searchByProductName()
      {
		 ArrayList<Product> list = new ArrayList<>();
		  List<Product> lst = viewAllProducts();
		  for(Product list1 : lst)
		  {
			  if(list1.getProduct_Name().equalsIgnoreCase(UserInteraction.productName))
			  {
				  list.add(list1);
			  }
		  }
		 
		return list;
      }
	  
	  public ArrayList<Product> searchBySupplierName()
	  {
		  ArrayList<Product> list = new ArrayList<>();
		  List<Product> lst = viewAllProducts();
		  for(Product list1 : lst)
		  {
			  if(list1.getSupplier().getFirst_Name().equalsIgnoreCase(UserInteraction.supplierName))
			  {
				  list.add(list1);
			  }
		  }
		 
		return list;
	  }
	  
		public ArrayList<Product> searchByCategoryName() 
		{
			ArrayList<Product> list = new ArrayList<>();
			  List<Product> lst = viewAllProducts();
			  for(Product list1 : lst)
			  {
				  if(list1.getCategory().getCategory_Name().equalsIgnoreCase(UserInteraction.categoryName))
				  {
					  list.add(list1);
				  }
			  }
			 
			return list;
		}
		
		public ArrayList<Product> searchBySubCategory()
		{
			ArrayList<Product> list = new ArrayList<>();
			  List<Product> lst = viewAllProducts();
			  for(Product list1 : lst)
			  {
				  if(list1.getSub_Category().getSub_Category_Name().equalsIgnoreCase(UserInteraction.sucCategoryName))
				  {
					  list.add(list1);
				  }
			  }
			 
			return list;
		}
		
		public ArrayList<Product> searchByRatings()
		{
			ArrayList<Product> list = new ArrayList<>();
			  List<Product> lst = viewAllProducts();
			  for(Product list1 : lst)
			  {
				  if(list1.getRatings() == UserInteraction.ratings)
				  {
					  list.add(list1);
				  }
			  }
			return list;
		}
		
		

	public Map<Integer, Product> getAllProducts() {

		return products;

	}

	@Override
	public void updateProductName(int productId, Product p, String pName)
	{
		PreparedStatement pstmt = null;
		  try {
			pstmt = getConnection().prepareStatement("update product set productname=? where productId = ?");
			pstmt.setString(1, pName);
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
	}

	@Override
	public void updateRetailPrice(int productId, Product p, double price) {
		PreparedStatement pstmt = null;
		  try {
			pstmt = getConnection().prepareStatement("update product set maxretailprice=? where productId = ?");
			pstmt.setDouble(1, price);
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
		
	}

	@Override
	public void updateExpiryDate(int productId, Product p, java.util.Date date) {
		PreparedStatement pstmt = null;
		  try {
			     date = new java.util.Date();
				java.sql.Date sqlExDate = new java.sql.Date(date.getTime());
			pstmt = getConnection().prepareStatement("update product set expirydate=? where productId = ?");
			pstmt.setDate(1, sqlExDate);
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
	}

	@Override
	public void updateRating(int productId, Product p, float ratings)
	{
		PreparedStatement pstmt = null;
		  try {
			    
			pstmt = getConnection().prepareStatement("update product set ratings=? where productId = ?");
			pstmt.setFloat(1, ratings);
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
		
	}

	@Override
	public void updateCategory(int productId, Product p, Category category) 
	{
		PreparedStatement pstmt = null;
		  try {
	    
			pstmt = getConnection().prepareStatement("update product set category_id=? where productId = ?");
			
			pstmt.setInt(1,category.getCategory_Id() );
			pstmt.setInt(2, productId);
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
	}

}
