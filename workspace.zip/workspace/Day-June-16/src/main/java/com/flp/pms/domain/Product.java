package com.flp.pms.domain;

import java.util.Date;
import java.util.List;

public class Product 
{
private int product_Id;
private String product_Name;
private String discription;
private Date manufacturing_Date;
private Date expiry_Date;
private double max_Retail_Prices;
private Category category;
private Sub_Category sub_Category;
private Supplier supplier;
private List<Discount> discount;
private int quantity;
private float ratings;

public Product() {}

public Product(int product_Id, String product_Name, String discription, Date manufacturing_Date, Date expiry_Date,
		double max_Retail_Prices, Category category, Sub_Category sub_Category, Supplier supplier,
		List<Discount> discount, int quantity, float ratings) {
	super();
	this.product_Id = product_Id;
	this.product_Name = product_Name;
	this.discription = discription;
	this.manufacturing_Date = manufacturing_Date;
	this.expiry_Date = expiry_Date;
	this.max_Retail_Prices = max_Retail_Prices;
	this.category = category;
	this.sub_Category = sub_Category;
	this.supplier = supplier;
	this.discount = discount;
	this.quantity = quantity;
	this.ratings = ratings;
}





public float getRatings() {
	return ratings;
}

public void setRatings(float ratings) {
	this.ratings = ratings;
}

public int getProduct_Id() {
	return product_Id;
}

public void setProduct_Id(int product_Id) {
	this.product_Id = product_Id;
}

public String getProduct_Name() {
	return product_Name;
}

public void setProduct_Name(String product_Name) {
	this.product_Name = product_Name;
}

public String getDiscription() {
	return discription;
}

public void setDiscription(String discription) {
	this.discription = discription;
}

public Date getManufacturing_Date() {
	return manufacturing_Date;
}

public void setManufacturing_Date(Date manufacturing_Date) {
	this.manufacturing_Date = manufacturing_Date;
}

public Date getExpiry_Date() {
	return expiry_Date;
}

public void setExpiry_Date(Date expiry_Date) {
	this.expiry_Date = expiry_Date;
}

public double getMax_Retail_Prices() {
	return max_Retail_Prices;
}

public void setMax_Retail_Prices(double max_Retail_Prices) {
	this.max_Retail_Prices = max_Retail_Prices;
}

public Category getCategory() {
	return category;
}

public void setCategory(Category category) {
	this.category = category;
}

public Sub_Category getSub_Category() {
	return sub_Category;
}

public void setSub_Category(Sub_Category sub_Category) {
	this.sub_Category = sub_Category;
}

public Supplier getSupplier() {
	return supplier;
}

public void setSupplier(Supplier supplier) {
	this.supplier = supplier;
}

public List<Discount> getDiscount() {
	return discount;
}

public void setDiscount(List<Discount> discount) {
	this.discount = discount;
}

public int getQuantity() {
	return quantity;
}

public void setQuantity(int quantity) {
	this.quantity = quantity;
}



@Override
public String toString() {
	return "Product [product_Id=" + product_Id + ", product_Name=" + product_Name + ", discription=" + discription
			+ ", manufacturing_Date=" + manufacturing_Date + ", expiry_Date=" + expiry_Date + ", max_Retail_Prices="
			+ max_Retail_Prices + ", category=" + category + ", sub_Category=" + sub_Category + ", supplier=" + supplier
			+ ", discount=" + discount + ", quantity=" + quantity + ", ratings=" + ratings + "]";
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((category == null) ? 0 : category.hashCode());
	result = prime * result + ((discount == null) ? 0 : discount.hashCode());
	result = prime * result + ((discription == null) ? 0 : discription.hashCode());
	result = prime * result + ((expiry_Date == null) ? 0 : expiry_Date.hashCode());
	result = prime * result + ((manufacturing_Date == null) ? 0 : manufacturing_Date.hashCode());
	long temp;
	temp = Double.doubleToLongBits(max_Retail_Prices);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	result = prime * result + product_Id;
	result = prime * result + ((product_Name == null) ? 0 : product_Name.hashCode());
	result = prime * result + quantity;
	result = prime * result + Float.floatToIntBits(ratings);
	result = prime * result + ((sub_Category == null) ? 0 : sub_Category.hashCode());
	result = prime * result + ((supplier == null) ? 0 : supplier.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Product other = (Product) obj;
	if (category == null) {
		if (other.category != null)
			return false;
	} else if (!category.equals(other.category))
		return false;
	if (discount == null) {
		if (other.discount != null)
			return false;
	} else if (!discount.equals(other.discount))
		return false;
	if (discription == null) {
		if (other.discription != null)
			return false;
	} else if (!discription.equals(other.discription))
		return false;
	if (expiry_Date == null) {
		if (other.expiry_Date != null)
			return false;
	} else if (!expiry_Date.equals(other.expiry_Date))
		return false;
	if (manufacturing_Date == null) {
		if (other.manufacturing_Date != null)
			return false;
	} else if (!manufacturing_Date.equals(other.manufacturing_Date))
		return false;
	if (Double.doubleToLongBits(max_Retail_Prices) != Double.doubleToLongBits(other.max_Retail_Prices))
		return false;
	if (product_Id != other.product_Id)
		return false;
	if (product_Name == null) {
		if (other.product_Name != null)
			return false;
	} else if (!product_Name.equals(other.product_Name))
		return false;
	if (quantity != other.quantity)
		return false;
	if (Float.floatToIntBits(ratings) != Float.floatToIntBits(other.ratings))
		return false;
	if (sub_Category == null) {
		if (other.sub_Category != null)
			return false;
	} else if (!sub_Category.equals(other.sub_Category))
		return false;
	if (supplier == null) {
		if (other.supplier != null)
			return false;
	} else if (!supplier.equals(other.supplier))
		return false;
	return true;
}


	


}
