package org.capg.IO;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class BufferInput 
{
static int count;
int size;
byte[] b=null;
static File file=new File("D:\\Demo\\workspace\\Day-May-12\\src\\main\\resources\\Buffer");
public static void main(String[] args) 
{
	BufferStudent bf = new BufferStudent();

	
	
	
	FileOutputStream fout=null;
	DataOutputStream dout=null;
	try {
		fout=new FileOutputStream(file);
		dout=new DataOutputStream(fout);
		

		String choice=null;
		
		do{
			
			bf.getDet();

		dout.writeInt(bf.getRegNo());
		dout.writeDouble(bf.feeAmt);
		dout.writeDouble(bf.getcMarks());
		dout.writeDouble(bf.getCcMarks());
		dout.writeDouble(bf.getJavaMarks());
		dout.writeUTF(bf.getStName());
		dout.writeUTF(bf.getGenderDet());
		Scanner scn = new Scanner(System.in);
		System.out.println("Wish to contine?[y|n]");
		choice=scn.next();
		count++;
		}while(choice.charAt(0)=='Y'||choice.charAt(0)=='y');
		
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try{
		dout.close();
		fout.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
}


	FileInputStream fin=null;
	DataInputStream din=null;
	
	{
	
	try {
		
		fin=new FileInputStream(file);
		din=new DataInputStream(fin);
		
		while(count>0){
		int regNo=din.readInt();
		size=din.readInt();
		b=new byte[size];
		din.read(b);
		double fee=din.readDouble();
		size=din.readInt();
		b=new byte[size];
		din.read(b);
		double c=din.readDouble();
		size=din.readInt();
		b=new byte[size];
		din.read(b);
		double cc=din.readDouble();
		size=din.readInt();
		b=new byte[size];
		din.read(b);
		double java=din.readDouble();
		size=din.readInt();
		b=new byte[size];
		din.read(b);
		String sname=din.readLine();
		size=din.readInt();
		b=new byte[size];
		din.read(b);
				
		String gender=din.readLine();
		
		double total = cc+c+java;
		
		System.out.print(sname + "\t" + regNo + "\t" + gender+  "\t"+ fee +"\t" + c +"\t" + cc + "\t" + java +"\t" +total);
		
		
		count--;
		}
		
	} catch (FileNotFoundException e ) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			din.close();
			fin.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
}
}
