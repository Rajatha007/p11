package org.capg.IO;

import java.util.Scanner;

public class BufferCond 
{

public static void main(String[] args) {
	

{
	
	BufferInput b1 = new BufferInput();
	
	
	}
}

}
	