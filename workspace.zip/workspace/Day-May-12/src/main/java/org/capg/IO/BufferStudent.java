package org.capg.IO;

import java.util.Scanner;

public class BufferStudent 
{
	String stName;
	int regNo;
	double feeAmt;
	String genderDet;
	double cMarks;
	double ccMarks;
	double javaMarks;
	
	
	
	public String getStName() {
		return stName;
	}

	public void setStName(String stName) {
		this.stName = stName;
	}

	public int getRegNo() {
		return regNo;
	}

	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}

	public double getFeeAmt() {
		return feeAmt;
	}

	public void setFeeAmt(double feeAmt) {
		this.feeAmt = feeAmt;
	}

	public String getGenderDet() {
		return genderDet;
	}

	public void setGenderDet(String genderDet) {
		this.genderDet = genderDet;
	}

	public double getcMarks() {
		return cMarks;
	}

	public void setcMarks(double cMarks) {
		this.cMarks = cMarks;
	}

	public double getCcMarks() {
		return ccMarks;
	}

	public void setCcMarks(double ccMarks) {
		this.ccMarks = ccMarks;
	}

	public double getJavaMarks() {
		return javaMarks;
	}

	public void setJavaMarks(double javaMarks) {
		this.javaMarks = javaMarks;
	}

	public void getDet()
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter Student Name: ");
		stName = scn.next();
		System.out.println("Enter Student Reg. No.: ");
		regNo = scn.nextInt();
		System.out.println("Enter Fee Amount : ");
		
		feeAmt = scn.nextDouble();
		System.out.println("Enter gender details : ");
		genderDet = scn.next();
		System.out.println("Enter C marks : ");
		cMarks = scn.nextDouble();
		System.out.println("Enter C++ Marks : ");
		ccMarks = scn.nextDouble();
		System.out.println("Enter Java Marks : ");
		javaMarks = scn.nextDouble();
	}
	
	public void display()
	{
		System.out.println("Student Name : " + stName);
	}
}
