package org.capg.Demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class File_CopyData 
{
public static void main(String[] args) {
		
		
		File file=new File("D:\\Demo\\workspace\\Day-May-12\\src\\main\\resources\\source");
		File file1 = new File("D:\\Demo\\workspace\\Day-May-12\\src\\main\\resources\\destination");
		FileReader fread=null;
		String str ="";
		FileWriter fwrite=null;
			
		try {
			fread=new FileReader(file);
			
			long fsize=file.length();
			
			while(fsize>0){
			int ch=fread.read();
			
			System.out.print((char)ch);
		
			str = str+(char)ch;
				fsize--;
				
			}
			fwrite=new FileWriter(file1,true);
			for(int i=0;i<str.length();i++)
				fwrite.write(str.charAt(i));
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				fread.close();
				fwrite.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		

	}

}


