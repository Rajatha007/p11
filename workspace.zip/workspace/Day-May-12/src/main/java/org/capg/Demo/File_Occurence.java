package org.capg.Demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class File_Occurence 
{
public static void main(String[] args) {
		
		
		File file=new File("D:\\Demo\\workspace\\Day-May-12\\src\\main\\resources\\occurence");
		FileReader fread=null;
		String str ="";
		String str1 ="";
		int occurence = 0;
			
		try {
			fread=new FileReader(file);
			long fsize=file.length();
			
			while(fsize>0){
			int ch=fread.read();
						
			str1 = str1+ ""+(char)ch;
			
			if((char)ch=='a'|| (char)ch=='e'|| (char)ch=='i'||(char)ch=='o'||(char)ch=='u'||(char)ch=='A'||(char)ch=='E'
					||(char)ch=='I'||(char)ch=='O'||(char)ch=='U')
			{
				occurence++;
			}
			
				fsize--;
				
			}
			System.out.println(str1);
			System.out.println("No. of Occurence : " + occurence);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(fread!=null)
				{
				fread.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		

	}
}
