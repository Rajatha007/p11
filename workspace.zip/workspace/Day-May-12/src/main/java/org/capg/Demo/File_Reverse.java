package org.capg.Demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class File_Reverse 
{
public static void main(String[] args) {
		
		
	File file=new File("D:\\Demo\\workspace\\Day-May-12\\src\\main\\resources\\reverse");
	FileReader fread=null;
	String str ="";
	String str1 = "";
		
	try {
		fread=new FileReader(file);
			
		long fsize=file.length();
		
		while(fsize>0){
		int ch=fread.read();
		
	
		str = str+(char)ch;
			fsize--;
			
		}
		System.out.println(str);
		
		for(int i=str.length()-1;i>=0;i--)
		{
			str1 = str1+str.charAt(i);
		}
			System.out.println(str1);
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			fread.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	

}
}
