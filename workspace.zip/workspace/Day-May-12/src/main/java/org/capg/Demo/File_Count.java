package org.capg.Demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.SynchronousQueue;

public class File_Count 
{
	
	public static void main(String[] args) {
			
			
			File file=new File("D:\\Demo\\workspace\\Day-May-12\\src\\main\\resources\\words");
			FileReader fread=null;
			String str1 ="";
			int countLines=1;
			int countWords = 0;
			
			try {
				fread=new FileReader(file);
				
				long fsize=file.length();
				
				while(fsize>0){
				int ch=fread.read();
							
				str1 = str1+ ""+(char)ch;
				
				if((char)ch=='\n')
				{
					countLines++;
				}
				if((char)ch==' ')
				{
					countWords++;
				}
					fsize--;
					
				}
				System.out.println(str1);
				System.out.println("No. of Lines : " + countLines);
				System.out.print("No. of words : ");
				System.out.print(countLines+countWords);
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					fread.close();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
			

		}
}
