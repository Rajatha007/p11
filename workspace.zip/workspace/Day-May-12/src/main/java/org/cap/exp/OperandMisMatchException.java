package org.cap.exp;

public class OperandMisMatchException extends Throwable
{
	public OperandMisMatchException(){
		super("Error! Operand should be Number!");
	}
	
	public OperandMisMatchException(String msg){
		super(msg);
	}
}
