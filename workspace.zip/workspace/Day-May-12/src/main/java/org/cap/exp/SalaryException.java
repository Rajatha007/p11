package org.cap.exp;

public class SalaryException extends Throwable
{
	public SalaryException(){
		super("Minimum balance should be 1000");
	}
	
	public SalaryException(String msg){
		super(msg);
	}
}
