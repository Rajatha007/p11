package org.cap.exp;

import java.util.Scanner;

public class Salary_Exp 
{
	private int accountId;
	private String accountName;
	private static int depositAmt;
	private String accountType;
	
	public static void main(String[] args)
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter 1. Saving Account  2.Current Account  3.Salary Account");
		int i = scn.nextInt();
		switch(i)
		{
		case 1 : System.out.println("Enter the amount to be deposited ");
				 depositAmt = scn.nextInt();
				 try {
				 if(depositAmt<1000)
					 throw new SalaryException();
					} catch (SalaryException e) {
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
				 System.out.println("Transaction Successfull!.....");
				 break;
					 
		case 2 : System.out.println("Enter the amount to be deposited ");
		 			depositAmt = scn.nextInt();
		 			try {
		 				if(depositAmt<5000)
			 throw new SalaryException1();
			} catch (SalaryException1 e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		 System.out.println("Transaction Successfull!.....");
		 break;
		
		case 3 : System.out.println("Enter the amount to be deposited ");
			     depositAmt = scn.nextInt();
			     System.out.println("Transaction Successfull!.....");
			     break;
			     default: System.out.println("Invalid input");
		}
	}
}
