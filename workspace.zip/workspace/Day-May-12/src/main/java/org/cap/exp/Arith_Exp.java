package org.cap.exp;

import java.util.Scanner;

public class Arith_Exp 
{
public static void main(String[] args) 
{
	int num1;
	int num2;
	int num;
	Scanner scn = new Scanner(System.in);
	System.out.println("Enter the 2 nos : ");
	num1 = scn.nextInt();
	num2 = scn.nextInt();
	try{
	num = num1/num2;
	System.out.println("Result is : " + num);
	} catch (ArithmeticException e) {
        System.out.println ("Can't divide by Zero"+e);
}
	System.out.println("Program complete");
}
}