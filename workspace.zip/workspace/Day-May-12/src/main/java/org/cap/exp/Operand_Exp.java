package org.cap.exp;


import java.util.Scanner;

public class Operand_Exp 
{
	
     long j = 0;

	public void cal() throws OperandMisMatchException,Throwable

	{
		
		int num1 = 0;
		long num2 = j;
		long num = num1+num2;
		System.out.println("result = " + num);
		throw new OperandMisMatchException("Inputs are not integers");
		
	}
	
}
