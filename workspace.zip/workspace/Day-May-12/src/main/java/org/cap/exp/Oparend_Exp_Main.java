package org.cap.exp;

public class Oparend_Exp_Main
{
	public static void main(String[] args) throws Throwable
	{
		{
		try{	
			new Operand_Exp().cal();;
			//throw new OperandMisMatchException();
		}catch(OperandMisMatchException e){
		System.out.println(e.getMessage());
			
		}
	}

}
}
