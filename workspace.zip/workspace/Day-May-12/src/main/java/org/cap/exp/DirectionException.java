package org.cap.exp;

public class DirectionException extends Throwable
{
	public DirectionException(){
		super(" Accident may occur !");
	}
	
	public DirectionException(String msg){
		super(msg);
	}
}
