package org.cap.exp;

import java.util.Scanner;

public class Collusion_Exp 
{
	int vehicle1;
	int vehicle2;
	public static void main(String[] args) 
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the direction of Vehicle1 : ");
		System.out.println("1.To go left  2.To go right");
		int i = scn.nextInt();
		System.out.println("Enter the direction of Vehicle2 : ");
		System.out.println("1.To go left  2.To go right");
		int j = scn.nextInt();
		try{
		if(i==j)
		
			throw new DirectionException();
		}catch(DirectionException e1) {
			System.out.println(e1.getMessage());
			e1.printStackTrace();
		}
	System.out.println("Program Complete");
}
}