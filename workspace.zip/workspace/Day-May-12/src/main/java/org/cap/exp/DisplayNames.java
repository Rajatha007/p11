package org.cap.exp;

import java.util.Scanner;
public class DisplayNames 
{
	public static void main(String[] args) {	
	String names;
	int rollNum;
	int arr[] = new int[10];
	String[] str = new String[10];
	Scanner scn = new Scanner(System.in) ;
	System.out.println("Enter the index number between 0 - 9 : ");
	int i = scn.nextInt();
	System.out.println("Enter the Roll no. : ");
	int j = scn.nextInt();
	System.out.println("Enter the student name: ");
	String s1 = scn.next();
	try{
	arr[i] = j;
	str[i] = s1;
	System.out.println("Details inserted successfully");
	}catch (ArrayIndexOutOfBoundsException e) {
        System.out.println("Array is out of Bounds"+e);				
			
	}
	System.out.println("Program complete");
	}
}

	

