package org.cap.exp;

public class SubClassSuperClass 
{
	 void show() throws Exception 
	  {  
		 System.out.println("parent class");  

	}
}

	 class Sub extends SubClassSuperClass 
	{
	       void show() throws Exception		//Correct  	  
	   {
	    	   System.out.println("child class"); 
	   }        
	
	 public static void main(String[] args)
	 {
	  try {
	   Sub s=new Sub();
	   s.show();
	   }
	  catch(Exception e){}
	 }  
	}

