package org.cap.exp;

public class SalaryException1 extends Throwable
{
	public SalaryException1(){
		super("Minimum balance should be 5000");
	}
	
	public SalaryException1(String msg){
		super(msg);
	}
}
