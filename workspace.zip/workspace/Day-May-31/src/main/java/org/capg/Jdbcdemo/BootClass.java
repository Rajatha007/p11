package org.capg.Jdbcdemo;

import java.util.Scanner;

public class BootClass 
{
public static void main(String[] args)
{
	menuSelection();
}
public static void menuSelection()
{
	Scanner scn = new Scanner(System.in);
	int option;
		Userinteraction ui=new Userinteraction();
		EmployeeDao empDao=new EmployeeDaoImpl();
		
		
		System.out.println("1.Create DateBase" +
				"\n2.Modify DataBase" +
				"\n3.Remove DateBase" +
				"\n4.View " +
				"\n5.Search" +
				"\n6.Exit");
System.out.println("Enter your option : ");
option = scn.nextInt();

switch(option)
{
case 1 : 
Employee emp=ui.getEmployee();
int count=empDao.addEmployee(emp);
System.out.println(ui.printMessage(count));
break;

case 2: 
break;

case 3: 
	break;
	
case 4:
	break;
	
case 5:
	break;
	
case 6 : System.exit(0);
}
		
		
	}
}
