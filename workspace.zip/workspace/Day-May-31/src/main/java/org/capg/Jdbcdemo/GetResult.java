package org.capg.Jdbcdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GetResult 
{
public static void main(String[] args) throws SQLException
{
	Connection conn=null;
	Statement stmt = null;
	String qry = "select email from employee where departmentNo = 202";
	//Load Driver Class
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	//Establish Connection
	try {
		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/capbd","root","india123");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(qry);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		while (rs.next())
		{
			String email = rs.getString(6);
			System.out.println(email);
		}
	
	}
}
}
