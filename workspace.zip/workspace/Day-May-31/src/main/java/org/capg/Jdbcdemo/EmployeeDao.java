package org.capg.Jdbcdemo;

public interface EmployeeDao 
{

	public int addEmployee(Employee employee);
	public void viewEmployee();
}
