package org.cap.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.cap.login.LoginServlet;
import org.cap.login.pojo.Login;

public class DaoLayerImpl implements DaoLayer
{
		public Connection toDataBase()
		{

			Connection con = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/servlet","root","india123");
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;
		}
		@Override
		public boolean isValidUser(Login login)
		{

			boolean flag=false;
			String sql = "select * from userLogin where username = ? and pswrd = ?";
			PreparedStatement pstmt;
			try {
				pstmt = toDataBase().prepareStatement(sql);
				pstmt.setString(1,login.getUserName() );
				pstmt.setString(2,login.getUserPwd());
				
				ResultSet rs = pstmt.executeQuery();
				if(rs.next())
					flag=true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			return flag;
		}
}
