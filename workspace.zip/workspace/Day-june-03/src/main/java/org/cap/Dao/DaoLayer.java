package org.cap.Dao;

import java.sql.Connection;

import org.cap.login.pojo.Login;

public interface DaoLayer
{
	public boolean isValidUser(Login login);
	public Connection toDataBase();
		
	}

