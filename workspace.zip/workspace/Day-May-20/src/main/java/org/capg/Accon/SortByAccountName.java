package org.capg.Accon;

import java.util.Comparator;

public class SortByAccountName implements Comparator<Accounts>
{

	public int compare(Accounts a1, Accounts a2) 
	{
		if(a1.getAccountName().compareTo(a2.getAccountName())>0)
			return 1;
		else if(a1.getAccountName().compareTo(a2.getAccountName())<0)
		return -1;
		
		else
			return 0;
	}

}
