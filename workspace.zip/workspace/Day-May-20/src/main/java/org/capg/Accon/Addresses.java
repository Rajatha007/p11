package org.capg.Accon;

import java.util.Scanner;

public class Addresses
{
	public int doorNo;
	public String stName;
	public String city;
	public String state;
	public Addresses(int doorNo, String stName, String city, String state) {
		super();
		this.doorNo = doorNo;
		this.stName = stName;
		this.city = city;
		this.state = state;
	}
	public int getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}
	public String getStName() {
		return stName;
	}
	public void setStName(String stName) {
		this.stName = stName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Addresses() {
		
	}
	@Override
	public String toString() {
		return "Addresses [doorNo=" + doorNo + ", stName=" + stName + ", city=" + city + ", state=" + state + "]";
	}

	
	
	

}
