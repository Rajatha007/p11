package org.capg.Accon;

public enum Types
{
	SAVINGS, CURRENT, JOINT, SALARY;
}
