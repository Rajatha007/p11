package org.capg.MapDem;

public class MainAcc 
{
	public static void main(String[] args) 
	{
		DAO d1 = new DAO();
		d1.store();
	}
}
