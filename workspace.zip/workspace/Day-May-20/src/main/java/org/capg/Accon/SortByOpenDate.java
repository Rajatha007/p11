package org.capg.Accon;

import java.util.Comparator;

public class SortByOpenDate implements Comparator<Accounts>
{

	public int compare(Accounts a1, Accounts a2) 
	{
		if(a1.getOpenDate().after(a2.getOpenDate()))
		return 1;
		else if (a1.getOpenDate().before(a2.getOpenDate()))
			return -1;
		else
			return 0;
			
	}



}
