package org.capg.MapDem;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Employe 
{
	private int empId;
	private String fName;
	private String lName;
	SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	Date dateOfBirth;
	Date dateOfJoin;
	Salary s1;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public SimpleDateFormat getSdf() {
		return sdf;
	}
	public void setSdf(SimpleDateFormat sdf) {
		this.sdf = sdf;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Date getDateOfJoin() {
		return dateOfJoin;
	}
	public void setDateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}
	public Salary getS1() {
		return s1;
	}
	public void setS1(Salary s1) {
		this.s1 = s1;
	}
	
	
	public Employe(int empId, String fName, String lName, Date dateOfBirth2, Date dateOfJoin2
			) {
		super();
		this.empId = empId;
		this.fName = fName;
		this.lName = lName;
		
		this.dateOfBirth = dateOfBirth2;
		this.dateOfJoin = dateOfJoin2;
		
	}
	
	
	public Employe() 
	{
	}
	@Override
	public String toString() {
		return "Employe [empId=" + empId + ", fName=" + fName + ", lName=" + lName +  ", dateOfBirth="
				+ dateOfBirth + ", dateOfJoin=" + dateOfJoin +  "]";
	}
	
	
	}
	
	

