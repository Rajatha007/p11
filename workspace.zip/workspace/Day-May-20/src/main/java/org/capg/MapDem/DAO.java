package org.capg.MapDem;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class DAO 
{
		
	public void store()
	{
		UserInterface ui = new UserInterface();
		try {
			
			Employe e1 =ui.getEmployeDetails();
			Salary s1 = ui.getSalDetails();
			
			
			HashMap hmap = new HashMap();
			
				if(hmap.equals(e1.getEmpId()))
				{
					
					hmap.put(e1, s1);
					System.out.println(hmap);
					
				}
				
			Set keys = hmap.keySet();
			
			
			Iterator it = keys.iterator(); 
			
			
			while(it.hasNext())
			{
				System.out.println(it.next());
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}	
}
