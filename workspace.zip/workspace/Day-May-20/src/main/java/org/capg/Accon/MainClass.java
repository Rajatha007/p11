package org.capg.Accon;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;


public class MainClass 
{
	
	static SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

	public static void main(String[] args) throws ParseException 
	{
		
		Accounts a1 = new Accounts(1, "Tom", 500.00, new Addresses(1892, "B.M.Road", "Bangalore", "Karnataka"), sdf.parse("25-05-2016"), "Savings");
		Accounts a2 = new Accounts(2, "Jerry", 1500.00, new Addresses(56, "JC Road", "Hyderabad", "Andra"), sdf.parse("20-05-2016"), "Salary");
		Accounts a3 = new Accounts(3, "Donald", 50000.00, new Addresses(78, "MG Road", "Chennai", "Karnataka"), sdf.parse("01-05-2016"), "current");
		Accounts a4 = new Accounts(4, "Mickey", 8910.00, new Addresses(953, "Brigade", "Mysore", "Karnataka"), sdf.parse("06-05-2016"), "Joint");
		Accounts a5 = new Accounts(5, "Bugs", 89100.00, new Addresses(245, "Avenew", "Vijaywada", "Telengana"),sdf.parse("09-05-2016"), "Savings");
		Accounts a6 = new Accounts(6, "Scooby", 7800.00, new Addresses(246, "TNagar", "Kanche", "TamilNadu"), sdf.parse("10-05-2016"), "Savings");
		Accounts a7 = new Accounts(7, "Popeye", 14560.00, new Addresses(2166, "Chrompet", "Mumbai", "Maharastra"), sdf.parse("15-05-2016"), "Savings");
		
		HashSet<Accounts> h1 = new HashSet<Accounts>();
		
		List<Accounts>lst=new ArrayList<Accounts>();
		
		h1.add(a1);
		h1.add(a2);
		h1.add(a3);
		h1.add(a4);
		h1.add(a5);
		h1.add(a6);
		h1.add(a7);
		
		
		for(Accounts acc1: h1)
		{
			lst.add(acc1);
			
		}
		
		Scanner scn = new Scanner(System.in);
		System.out.println("To Sort in order  ");
		System.out.println("Press 1. By Account No. 2. By Account Name 3. By Open Date 4. By City");
		int i = scn.nextInt();
		
		switch(i)
		{
		case 1 : Collections.sort(lst, new SortByAccountNo());
		break;
		
		case 2 : Collections.sort(lst, new SortByAccountName());
		break;
		
		case 3 : Collections.sort(lst, new SortByOpenDate());
		break;
		
		case 4 : Collections.sort(lst, new SortByCity());
		break;
		default : System.out.println("Invalid Input");
		}
		
		Iterator<Accounts> it= lst.iterator();
		while(it.hasNext())
			System.out.println(it.next());
		

	}
	}

