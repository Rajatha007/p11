package org.capg.Accon;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Accounts 
{
	private int accountNo;
	private String accountName;
	private double amount;
	public Addresses a1;
	SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	Date openDate;
	private String accountType;
	
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Addresses getA1() {
		return a1;
	}
	public void setA1(Addresses a1) {
		this.a1 = a1;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "Accounts [accountNo=" + accountNo + ", accountName=" + accountName + ", amount=" + amount + ", a1=" + 
				   "openDate=" + openDate + ", accountType=" + accountType + "City = " + a1.city + "]";
	}
	public Accounts(int accountNo, String accountName, double amount, Addresses a1,
			 Date openDate, String accountType) {
		super();
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.amount = amount;
		this.a1 = a1;	
		this.openDate = openDate;
		this.accountType = accountType;
	}
	public Accounts() {
		
	}
	
	
	
	}
	
	
	
	
	
	
	
	

