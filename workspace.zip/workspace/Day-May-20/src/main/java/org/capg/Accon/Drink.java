package org.capg.Accon;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;


public class Drink {
int count;
int accumulated;
public Drink() {}
public void record(int v) {
count++;
accumulated += v;
}
public int average() {
return accumulated/count;
}



}
		
			

			



		 


			
			 
	
			 
	
		
		

