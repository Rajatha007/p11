package org.capg.MapDem;

public class Salary
{
 private int noOfDaysWorked;
 private double salPerDay;
public int getNoOfDaysWorked() {
	return noOfDaysWorked;
}
public void setNoOfDaysWorked(int noOfDaysWorked) {
	this.noOfDaysWorked = noOfDaysWorked;
}
public double getSalPerDay() {
	return salPerDay;
}
public void setSalPerDay(double salPerDay) {
	this.salPerDay = salPerDay;
}
@Override
public String toString() {
	return "Salary [noOfDaysWorked=" + noOfDaysWorked + ", salPerDay=" + salPerDay + "]";
}
public Salary(int noOfDaysWorked, double salPerDay) {
	super();
	this.noOfDaysWorked = noOfDaysWorked;
	this.salPerDay = salPerDay;
}
public Salary() {
}
 

 
}
