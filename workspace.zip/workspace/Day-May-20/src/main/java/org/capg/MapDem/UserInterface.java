package org.capg.MapDem;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class UserInterface 
{
	public Employe getEmployeDetails() throws ParseException
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Employee Id: ");
		int empId = scn.nextInt();
		System.out.println("Enter Employee First Name : ");
		String fName = scn.next();
		System.out.println("Enter Employee Last Name : ");
		String lName = scn.next();
		System.out.println("Enter Employee Date of Birth : ");
		String dob = scn.next();
		System.out.println("Enter Employee Date of Join : ");
		String doj = scn.next();	
		
		Date dateOfBirth = sdf.parse(dob);
		Date dateOfJoin = sdf.parse(doj);
		
	
		Employe emp = new Employe(empId, fName, lName, dateOfBirth, dateOfJoin);
		return emp;
		
	}
	
	public Salary getSalDetails()
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter No. of Days worked : ");
		int noOfDaysWorked = scn.nextInt();
		System.out.println("Enter Salary per day : ");
		double salPerDay = scn.nextDouble();
		
		Salary sal = new Salary(noOfDaysWorked, salPerDay);
		return sal;
		
	}
	
}
