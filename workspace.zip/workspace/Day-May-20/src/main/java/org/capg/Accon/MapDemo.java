package org.capg.Accon;

import java.util.HashMap;

public class MapDemo 
{
 public static void main(String[] args) 
 {
	 HashMap map = new HashMap();
	 HashMap map1 = new HashMap();
	 
	 map1.put("hi", 565);
	 map1.put("hello", 5133);
	 map1.put("h", 5546);
	 map1.put("hbn", 5433);
	 
	 map.put(1, "tom");
	 map.put(2, "Jerry");
	 map.put(3, "Popeye");
	 map.put(4, "Olive");
	 map.put(5, "Bugs");
	 map.put(6, "Mickey");
	 map.put(7, "Donald");
	 System.out.println(map);
	 
	 map.remove(1);
	
	 System.out.println(map);
	 
	 System.out.println(map.containsKey(5));
	
	 
	 System.out.println(map.entrySet());
	 map.putAll(map1);
	 System.out.println(map);
	 
	 System.out.println(map1.isEmpty());
	 
	System.out.println( map.get(4));
	
	System.out.println(map.keySet());
	
	System.out.println(map.values());
	
	System.out.println(map.containsValue(565));
	
	map.putIfAbsent(9, "task");
	
	map.replace(1, "Jerry");
	
	System.out.println(map.size());
	
	System.out.println(map);
	 
	 map.clear();
}
}
