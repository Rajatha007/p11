package com.flp.pms.view;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.flp.pms.util.Validate;

public class UserInteraction {
	private static final Scanner scn = null;
	public static String productName;
	public static String supplierName;
	public static String categoryName;
	public static String sucCategoryName;
	public static int id;
	public static float ratings;
	public static int productId;
	public static int update;
	public static float search;
	IProductService ips = new ProductServiceImpl();
	Scanner sc = new Scanner(System.in);

	public Product addProduct(List<Category> categories, List<Sub_Category> subCategories, List<Supplier> suppliers,
			List<Discount> discounts) {
		Scanner scn = new Scanner(System.in);
		boolean flag = false;
		Product product = new Product();

		// Prompt Valid Product Name
		String productName;
		do {
			System.out.println("Enter Product Name:");
			productName = scn.nextLine();
			flag = Validate.isValidProductName(productName);
			if (!flag)
				System.out.println("Invalid Product Name");
		} while (!flag);
		product.setProduct_Name(productName);

		// Prompt Product discription

		String discription;
		System.out.println("Enter Product Description : ");
		discription = scn.nextLine();
		product.setDiscription(discription);

		// prompt ManufacturingDate
		String manufact_Date;
		do {
			System.out.println("Enter Manufacturing Date:[dd-MMM-yyyy]");
			manufact_Date = scn.next();
			flag = Validate.isValidDate(manufact_Date);
			if (!flag)
				System.out.println("Invalid Date Format!");

		} while (!flag);
		product.setManufacturing_Date(new Date(manufact_Date));

		// prompt ExpiryDate
		String expiry_Date;
		boolean ex_flag = false;

		// Check valid Expiry Date
		do {

			// Validate Date Format
			do {

				System.out.println("Enter Expiry Date:[dd-MM-yyyy]");
				expiry_Date = scn.next();
				flag = Validate.isValidDate(expiry_Date);
				if (!flag)
					System.out.println("Invalid Date Format!");

			} while (!flag);

			ex_flag = Validate.isValidexpiryDate(new Date(expiry_Date));

			if (!ex_flag)
				System.out.println("Expiry Date must be future Date!");
		} while (!ex_flag);
		product.setExpiry_Date(new Date(expiry_Date));

		// Prompt Maximum Retail Price
		System.out.println("Enter Maximum Retail Price ");
		double prices = scn.nextDouble();
		product.setMax_Retail_Prices(prices);

		// Prompt Quantity
		int quantity = 0;
		do {
			System.out.println("Enter Product Quantity: ");
			quantity = scn.nextInt();
			flag = Validate.isValidQuantity(quantity);
			if (!flag)
				System.out.println("Enter valid quantity");
		} while (!flag);
		product.setQuantity(quantity);

		// Prompt Ratings
		float ratings = 0.0f;
		do {
			System.out.println("Enter the ratings between 1.0 & 5.0");
			ratings = scn.nextFloat();
			flag = Validate.isValidRating(ratings);
			if (!flag)
				System.out.println("Invalid Ratings");
		} while (!flag);
		product.setRatings(ratings);

		// prompt valid category Details
		Category category = getCategory(categories);
		product.setCategory(category);

		// Prompt SubCategory Details
		Sub_Category subCategory = getSubCategory(subCategories, category);
		product.setSub_Category(subCategory);

		// Prompt Suppliers
		Supplier supplier = getSupplier(suppliers);
		product.setSupplier(supplier);

		// Prompt Dicsount Details
		List<Discount> discounts2 = getDiscounts(discounts);
		product.setDiscount(discounts2);
		return product;
	}

	public Category getCategory(List<Category> categories) {
		// Choose Category
		Category category = null;
		boolean flag = false;

		Scanner sc = new Scanner(System.in);
		int choice;

		do {
			System.out.println("Choose Catgeory Id:");
			for (Category category1 : categories)
				System.out.println(category1.getCategory_Id() + "\t" + category1.getCategory_Name() + "\t"
						+ category1.getDiscription());
			choice = sc.nextInt();

			// Validate the Category
			for (Category category1 : categories) {
				if (choice == category1.getCategory_Id()) {
					category = category1;
					flag = true;
					break;
				}
			}
			if (!flag)
				System.out.println("* Please choose Valid Category ID!");
		} while (!flag);

		return category;
	}

	// Choose Sub Category
	public Sub_Category getSubCategory(List<Sub_Category> categories, Category category) {		
		Sub_Category subCategory = null;
		Scanner scanner = new Scanner(System.in);
		int option;
		boolean flag = false;
		do {
			System.out.println("Choose Product Sub Category:");
			for (Sub_Category subCategory2 : categories) {
				if (subCategory2.getCategory_Id().getCategory_Id() == category.getCategory_Id())
					System.out.println( subCategory2.getSub_Category_Id()+"\t"+subCategory2.getSub_Category_Name());
			}
			option = scanner.nextInt();
			// Check Valid SubCategory
			for (Sub_Category subCategory2 : categories) {
				if (option == subCategory2.getSub_Category_Id()) {
					subCategory = subCategory2;
					flag = true;
					break;
				}
			}

			if (!flag)
				System.out.println("* Please choose valid Sub category!");

		} while (!flag);

		return subCategory;
	}

	public Supplier getSupplier(List<Supplier> suppliers) {
		// Choose Supplier
		Supplier supplier = null;
		boolean flag1 = false;

		Scanner sc = new Scanner(System.in);
		int choice;

		do {
			System.out.println("Choose Supplier:");
			for (Supplier supplier1 : suppliers)
				System.out.println(supplier1.getSupplier_Id() + "\t" + supplier1.getFirst_Name() + "\t"
						+ supplier1.getLast_Name() + "\t" + supplier1.getCity() + "\t" + supplier1.getState() + "\t"
						+ supplier1.getPinCode() + "\t" + supplier1.getContactNo());
			choice = sc.nextInt();
			// Validate the Category
			for (Supplier supplier1 : suppliers) {
				if (choice == supplier1.getSupplier_Id()) {
					supplier = supplier1;
					flag1 = true;
					break;
				}
			}
			if (!flag1)
				System.out.println("* Please choose Valid Supplier ID!");
		} while (!flag1);

		return supplier;
	}

	// Prompt Discount Details

	public List<Discount> getDiscounts(List<Discount> discounts) {
		List<Discount> discounts2 = new ArrayList<Discount>();
		Scanner sc = new Scanner(System.in);
		int option = 0;
		boolean flag = false;
		String choice = null;

		do {
			flag = false;
			do {
				System.out.println("Choose Dicounts for the Product:");
				for (Discount discount : discounts) {
					// check valid discounts
					if (discount.getValidThru().after(new Date())) {
						// System.out.println(discount.getValidThru());
						System.out.println(discount.getDiscount_Id() + "\t" + discount.getDiscount_Name() + "\t"
								+ discount.getDescription() + "\t" + discount.getDiscount_percentage());
					}

				}
				option = sc.nextInt();

				// Validate Discount
				L3: for (Discount discount : discounts) {
					if (discount.getDiscount_Id() == option) {
						discounts2.add(discount);
						flag = true;
						break L3;
					}
				}

				if (!flag)
					System.out.println("* Choose Valid Discount Id!");

			} while (!flag);

			System.out.println("You wish to add more discounts for this product?[Y|N]");
			choice = sc.next();

		} while (choice.charAt(0) == 'y' || choice.charAt(0) == 'Y');

		return discounts2;
	}
	
	public void viewProducts(List<Product> lst)
	{
		if (!lst.isEmpty()){
		for(Product list : lst)
		{
			System.out.println(list);
		}
		}
		else {
			System.out.println("No produts available to show.");
		}
	}

	public void getProductToDelete() 
	{
		System.out.println("Enter the product Id to be deleted : ");
		id = sc.nextInt();
		boolean flag = ips.removeProduct(id);
		if (flag == false) {
			System.out.println("Product Not found");
		} else {
			System.out.println("Product deleted");
		}
	}

	

	public void getNameToBeSearched() {
		System.out.println("Enter the Product name to be searched : ");
		productName = sc.next();
	}

	public void getSerchedName() {
		ArrayList<Product> list = ips.searchByProductName();
		if (list.isEmpty()) {
			System.out.println("No Product found");
		} else {
			System.out.println(list);
		}

	}

	public void getSupplierNameToSearch() {
		System.out.println("Enter the Supplier name to be searched : ");
		supplierName = sc.next();
	}

	public void getSupSearchedName() {
		ArrayList<Product> list = ips.searchBySupplierName();
		if (list.isEmpty()) {
			System.out.println("No Product found");
		} else {
			System.out.println(list);
		}
	}

	public void getCategoryNameSearch() {
		System.out.println("Enter the Category name to be searched : ");
		categoryName = sc.next();
	}

	public void getCatSerchName() {
		ArrayList<Product> list = ips.searchByCategoryName();
		if (list.isEmpty()) {
			System.out.println("No Product found");
		} else {
			System.out.println(list);
		}
	}

	public void getSubCategoryName() {
		System.out.println("Enter the Sub Category name to be searched : ");
		sucCategoryName = sc.next();
	}

	public void getSubCatSearch() {
		ArrayList<Product> list = ips.searchBySubCategory();
		if (list.isEmpty()) {
			System.out.println("No Product found");
		} else {
			System.out.println(list);
		}
	}

	public void getRatings() {
		System.out.println("Enter the Ratings to be searched : ");
		ratings = sc.nextFloat();
	}

	public void getRatingSearch() {
		ArrayList<Product> list = ips.searchByRatings();
		if (list.isEmpty()) {
			System.out.println("No Product found");
		} else {
			System.out.println(list);
		}
	}

	public void getProductNameModify() {
		System.out.println("Enter the Ratings to be searched : ");
		ratings = scn.nextFloat();
	}

	public int getProductId() {
		System.out.println("Enter the Product Id of the Product to be modified : ");
		productId = sc.nextInt();
		return productId;
	}

	public String validateModifingName() {
		boolean flag = false;
		String productName;
		do {
			System.out.println("Enter Product Name:");
			productName = sc.next();
			flag = Validate.isValidProductName(productName);
			if (!flag)
				System.out.println("Invalid Product Name");
		} while (!flag);

		return productName;
	}

	public double getRetailPrice() {
		System.out.println("Enter the retail Price : ");
		double price = sc.nextDouble();
		return price;

	}

	public Date validateExpiryDate() {
		String expiry_Date;
		boolean ex_flag = false;
		boolean flag = false;
		// Check valid Expiry Date
		do {
 
			// Validate Date Format
			do {

				System.out.println("Enter Expiry Date:[dd-MM-yyyy]");
				expiry_Date = sc.next();
				flag = Validate.isValidDate(expiry_Date);
				if (!flag)
					System.out.println("Invalid Date Format!");

			} while (!flag);

			ex_flag = Validate.isValidexpiryDate(new Date(expiry_Date));

			if (!ex_flag)
				System.out.println("Expiry Date must be future Date!");
		} while (!ex_flag);
		return new Date(expiry_Date);

	}

	public float getRatingsValidation() {
		boolean flag = false;
		float ratings = 0.0f;
		do {
			System.out.println("Enter the ratings between 1.0 & 5.0");
			ratings = sc.nextFloat();
			flag = Validate.isValidRating(ratings);
			if (!flag)
				System.out.println("Invalid Ratings");
		} while (!flag);

		return ratings;

	}

}
