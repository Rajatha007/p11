package com.flp.pms.view;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.flp.pms.util.Validate;

public class BootClass 
{
public static void main(String[] args) 
{
	menuSelection();
}

public static void menuSelection()
{
	int option;
	String choice=null;
	Scanner scn = new Scanner(System.in);
	UserInteraction userInteraction=new UserInteraction();
	IProductService iProductService = new ProductServiceImpl();
	Product product = null;
	
	
		
	do{
	System.out.println("1.Create Product" +
									"\n2.Modify Product" +
									"\n3.Remove Product" +
									"\n4.View All Product" +
									"\n5.Search Product" +
									"\n6.Exit");
	System.out.println("Enter your option : ");
	option = scn.nextInt();
	
	switch(option)
	{	
	case 1 :	  
				   product=userInteraction.addProduct(iProductService.getAllCategory(),
				   iProductService.getAllSubCategory(),
				   iProductService.getAllSupplier(),
				   iProductService.getAllDiscounts());
				   iProductService.addProduct(product);
				  System.out.println("Product Sucessfully Added");			  
				  break;
	
	case 2 :  
		            	int productId=userInteraction.getProductId();
						boolean flag=iProductService.validateProductId(productId);
						if (flag == true)
						{
						
							System.out.println("1.To modify name"+
									 "\n2.To modify retail price" +
										"\n3. To modify expiry date"+
									"\n4. To modify Rating"+
									"\n5. To modify category");
										  int ch = scn.nextInt();
						  switch(ch)
						  {
					  case 1 : String name =userInteraction.validateModifingName();
						  				iProductService.updateProductName(productId,product, name);		               
						               
							  break;
							  
						case 2: double price = userInteraction.getRetailPrice();
								iProductService.updateRetailPrice(productId,product, price);
							  break;
							  
						  case 3 : Date date = userInteraction.validateExpiryDate();
						 			iProductService.updateExpiryDate(productId,product, date);
							  break;
							  
						  case 4 : float ratings = userInteraction.getRatingsValidation();
						  			iProductService.updateRating(productId,product, ratings);
							  break;
							  
						  case 5 :  Category category =  userInteraction.getCategory(iProductService.getAllCategory());
						  				iProductService.updateCategory(productId,product, category);
							  break;		  
							  
						  }
						}
						  else
							{
								System.out.println("Invalid Product Id");
							}
					
				  
				  break;	
		
	case 3 : userInteraction.getProductToDelete();
		break;
		
	case 4 :	List<Product> li=iProductService.viewAllProducts();
					userInteraction.viewProducts(li);
		break;
	case 5 : System.out.println("1.By Name"+
												"\n2.By Supplier/Producer"+
												"\n3.By Category"+
												"\n4.By SubCategory"+
												"\n5.By Ratings");
	   int ch1 = scn.nextInt();
	   
	   switch(ch1)
		  {
		  case 1 : userInteraction.getNameToBeSearched();
		  				iProductService.searchByProductName();
		  				userInteraction.getSerchedName();
			  break;
			  
		  case 2: userInteraction.getSupplierNameToSearch();
		  				iProductService.searchBySupplierName();
		  				userInteraction.getSupSearchedName();
			  break;
			  
		  case 3 : userInteraction.getCategoryNameSearch();
		  				iProductService.searchByCategoryName();
		  				userInteraction.getCatSerchName();
			  break;
			  
		  case 4 : userInteraction.getSubCategoryName();
						iProductService.searchBySubCategory();
						userInteraction.getSubCatSearch();
			  break;
			  
		  case 5 : userInteraction.getRatings();
						iProductService.searchByRatings();
					userInteraction.getRatingSearch();  
	   break;
	
		  }

	break;
	case 6 : System.exit(0);
		break;
	}
		System.out.println("You wish to continue?[Y|N]");
		choice= scn.next();
	}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
	
	}
}
