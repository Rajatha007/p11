package org.cap.Demo;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="Employee_Details")

public class Employee
{
	@Id
	@GeneratedValue
	private int empId;
	
	@Column(nullable=false)
	private String  firstName;
	
	@Column( name="LastName")
	private String lastName;
	
	@Basic
	private double salary;
	
	@Temporal(TemporalType.DATE)
	private Date dateOfBirth;
	
	@Temporal(TemporalType.DATE)
	private Date dateOfJoin;
	
	@Column(nullable=false)
	private String empEmail;
	
	public Employee()
	{
		
	}

	public Employee( String firstName, String lastName, double salary, Date dateOfBirth, Date dateOfJoin,
			String custEmail) {
		super();
		//this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoin = dateOfJoin;
		this.empEmail = custEmail;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDateOfJoin() {
		return dateOfJoin;
	}

	public void setDateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}

	public String getCustEmail() {
		return empEmail;
	}

	public void setCustEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	
	
	
}
