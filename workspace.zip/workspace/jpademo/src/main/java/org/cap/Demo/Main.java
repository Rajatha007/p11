package org.cap.Demo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.CreateKeySecondPass;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class Main 
{
static Scanner scn = new Scanner(System.in);
static String choice;
static String choice1;
public static void main(String[] args) 
{
	menuSelection();
}
public static void menuSelection()
{
	
	do{
	System.out.println("1.Create" +
			"\n2.Read" +
			"\n3.Delete" +
			"\n4.Update" +
			"\n5.List" +
			"\n6.Exit");
   System.out.println("Enter your option : ");
   int option = scn.nextInt();
 
   switch (option) 
   {

   		case 1: 
   			do{
   			System.out.println("Enter First Name : ");
   					String fName = scn.next();
   					System.out.println("Enter Last Name : ");
   					String lName = scn.next();
   					System.out.println("Enter Salary : ");
   					double sal = scn.nextDouble();
   					System.out.println("Enter Date of Birth : ");
   					String dBirth = scn.next();
   					
   					System.out.println("Enter Date of Join: ");
   					String doj = scn.next();  				
   					
   					System.out.println("Enter Email id: ");
   					String email = scn.next();
   			create(fName, lName, sal, dBirth, doj, email);
   		 System.out.println("You wish to continue?[Y|N]");
   		choice1= scn.next();
   	} while(choice1.charAt(0)=='y'||choice1.charAt(0)=='Y');
   			
   			
	break;

   		case 2:
   			break;
   			
   		case 3:
   			break;
   			
   		case 4:
   			break;
   			
   		case 5:
   			break;
   			
   		case 6:
   			break;
	
   }System.out.println("You wish to continue?[Y|N]");
	choice= scn.next();
} while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');

}

public static void create(String firstName,String lastName,double sal,String dBirth,String doj,String email)
{
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	Date dob = null;
	Date dJoin = null;
	try {
			dob = format.parse(dBirth);
		

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	

		try {
		dJoin = format.parse(doj);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
				e.printStackTrace();
			}
	AnnotationConfiguration config=new AnnotationConfiguration();
	config.addAnnotatedClass(Employee.class);
	config.configure();
	new SchemaExport(config).create(true, true);
	SessionFactory sessfactory = config.buildSessionFactory();
	Session session=sessfactory.openSession();
	org.hibernate.Transaction trans= session.beginTransaction();
	Employee employee = new Employee(firstName, lastName, sal, new java.sql.Date(dob.getTime()), new java.sql.Date(dJoin.getTime()), email);
	session.save(employee);
	trans.commit();
	session.close();
}
}
