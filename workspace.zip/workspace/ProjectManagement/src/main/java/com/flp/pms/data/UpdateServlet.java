package com.flp.pms.data;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.ProductDaoImplforMap;
import com.flp.pms.domain.Product;
import com.google.gson.Gson;

public class UpdateServlet extends  HttpServlet
{
	private static final long serialVersionUID = 1L;
	public static int id;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		ProductDaoImplforMap db = new ProductDaoImplforMap();
		String updt = request.getParameter("updt");
		String option = request.getParameter("option");
		ServletContext context=getServletContext();  
		context.setAttribute("productid",updt);  
		id = Integer.parseInt(updt);
		if(option.equals("Name"))
		{
			response.sendRedirect("pages/updatename.html");
			  	   
		}
		
		else if(option.equals("Price"))
		{
			response.sendRedirect("pages/updateprice.html");
			  	   
		}
		
		else if(option.equals("Expiry Date"))
		{
			response.sendRedirect("pages/updateexdate.html");
		}
		
		else if(option.equals("Ratings"))
		{
			response.sendRedirect("pages/updaterating.html");
			  	   
		}
		
		else if(option.equals("Category"))
		{
			response.sendRedirect("pages/updatecategory.html");
			  	   
		}
}
}