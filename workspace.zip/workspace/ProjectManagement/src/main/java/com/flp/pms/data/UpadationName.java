package com.flp.pms.data;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplforMap;
import com.flp.pms.domain.Product;

public class UpadationName extends  HttpServlet{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pname = request.getParameter("pname");
		Product p = new Product();
		int id =UpdateServlet.id;
		IProductDao ips = new ProductDaoImplforMap();
		ips.updateProductName(id, p, pname);
		response.sendRedirect("pages/UpdateSuccess.html");
		
}
}
