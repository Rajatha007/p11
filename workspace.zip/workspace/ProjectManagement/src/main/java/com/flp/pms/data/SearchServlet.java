package com.flp.pms.data;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.ProductDaoImplforMap;
import com.flp.pms.domain.Product;
import com.google.gson.Gson;

public class SearchServlet  extends  HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		
		ProductDaoImplforMap db = new ProductDaoImplforMap();

		String option = request.getParameter("option");
		String search = request.getParameter("search");
		
		if(option.equals("Name"))
		{
			List<Product> list = db.searchByProductName(search);
			
			Gson myJson=new Gson();
			
			String productjson=myJson.toJson(list);		
			  out.println(productjson);
			  db.storeJson(productjson);
			  response.sendRedirect("pages/searchres.html");
			  	   
		}
		
		else if(option.equals("Supplier"))
		{
				List<Product> list = db.searchBySupplierName(search);
			
			Gson myJson=new Gson();
			
			String productjson=myJson.toJson(list);		
			  out.println(productjson);
			  db.storeJson(productjson);
			  response.sendRedirect("pages/searchres.html");
			  	   
		}
		
		else if(option.equals("Ratings"))
		{
				List<Product> list = db.searchByRatings(Double.parseDouble(search));
			
			Gson myJson=new Gson();
			
			String productjson=myJson.toJson(list);		
			  out.println(productjson);
			  db.storeJson(productjson);
			  response.sendRedirect("pages/searchres.html");
			  	   
		}
		
		else if(option.equals("Category"))
		{
				List<Product> list = db.searchByCategoryName(search);
			
			Gson myJson=new Gson();
			
			String productjson=myJson.toJson(list);		
			  out.println(productjson);
			  db.storeJson(productjson);
			  response.sendRedirect("pages/searchres.html");
			  	   
		}
		
		else if(option.equals("SubCategory"))
		{
				List<Product> list = db.searchBySubCategory(search);
			
			Gson myJson=new Gson();
			
			String productjson=myJson.toJson(list);		
			  out.println(productjson);
			  db.storeJson(productjson);
			  response.sendRedirect("pages/searchres.html");
			  	   
		}
}
}