package com.flp.pms.data;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.ProductDaoImplforMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;

public class SaveProducts  extends  HttpServlet{
private static final long serialVersionUID = 1L;

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
String pname = request.getParameter("pname");
String description = request.getParameter("description");
String manufacturingdate = request.getParameter("manufacturingdate");
String expirydate = request.getParameter("expirydate");
String price = request.getParameter("price");
String pCategory = request.getParameter("pCategory");
String pSubCategory = request.getParameter("pSubCategory");
String suppliers = request.getParameter("suppliers");
String[] discount = request.getParameterValues("discount");
String quantity = request.getParameter("quantity");
String rating = request.getParameter("rating");

Product product = new Product();

product.setProduct_Name(pname);
product.setDiscription(description);
SimpleDateFormat myFormat=new SimpleDateFormat("yyyy-MM-dd");
Date eDom=null;
Date eDoe=null;
try {
	eDom=myFormat.parse(manufacturingdate);
	eDoe=myFormat.parse(expirydate);
} catch (ParseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

product.setManufacturing_Date(eDom);
product.setExpiry_Date(eDoe);
product.setMax_Retail_Prices(Double.parseDouble(price));

 ProductDaoImplforMap db = new ProductDaoImplforMap();
Category cat=new Category();
cat.setCategory_Id(Integer.parseInt(pCategory));
product.setCategory(cat);
// List All SubCategory
Sub_Category sub = null;
List<Sub_Category> listSubCategory = db.getAllSubCategory();
for (Sub_Category subCategory : listSubCategory) {
	if (subCategory.getSub_Category_Id() == Integer.parseInt(pSubCategory))
		sub = subCategory;
	product.setSub_Category(sub);
}
// List All Supplier
Supplier sup = null;
List<Supplier> listSupplier = db.getAllSuppliers();
for (Supplier supplier : listSupplier) {
	if (supplier.getSupplier_Id() == Integer.parseInt(suppliers))
		sup = supplier;
	product.setSupplier(sup);
}

List<Discount> appliedDiscounts = new ArrayList<>();
for(Discount discount1:db.getAllDiscounts())
	for(String iD: discount)
		if(Integer.parseInt(iD)==discount1.getDiscount_Id())
			appliedDiscounts.add(discount1);

product.setDiscount(appliedDiscounts);

product.setQuantity(Integer.parseInt(quantity));

product.setRatings(Float.parseFloat(rating));

boolean flag=db.addProduct(product);
if(flag==true)
{
	response.sendRedirect("pages/success.html");
}
	else
		response.sendRedirect("pages/error.html");
}

}




