package com.flp.pms.data;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.ProductDaoImplforMap;

public class DeleteProduct extends  HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	String pno = request.getParameter("pno");
	
	 ProductDaoImplforMap db = new ProductDaoImplforMap();
	 
	 boolean flag=db.removeProduct(Integer.parseInt(pno));
	 if(flag==true)
	 {
	 	response.sendRedirect("pages/success.html");
	 }
	 	else
	 		response.sendRedirect("pages/error.html");
	 }
}