app.controller("myController", function($scope,$http) {
	
	$scope.getCategories = function() {
		var url = 'http://localhost:8080/ProjectManagement/CategoryList';
		$http.get(url)
		.success(function(response) 
				{
			$scope.cats = response;
		})
		.error(function(msg) {
			$scope.cats = msg;
		});

	};
	
	
	$scope.getSupplier = function() {
		var url = 'http://localhost:8080/ProjectManagement/SupplierList';
		$http.get(url)
		.success(function(response) 
				{
			$scope.sups = response;
		})
		.error(function(msg) {
			$scope.sups = msg;
		});

		
	};
	
	
	$scope.getSubCategory = function() {
		var url = 'http://localhost:8080/ProjectManagement/SubCategoryList';
		$http.get(url)
		.success(function(response) 
				{
			$scope.sub = response;
		})
		.error(function(msg) {
			$scope.sub = msg;
		});

	};

	$scope.getDiscount = function() {
		var url = 'http://localhost:8080/ProjectManagement/DiscountList';
		$http.get(url)
		.success(function(response) 
				{
			$scope.dis = response;
		})
		.error(function(msg) {
			$scope.dis = msg;
		});

	};
	
	$scope.search = function() {
		var url = 'http://localhost:8080/ProjectManagement/pages/mainpage.html';
		$http.get(url)
		.success(function(response) 
				{
			$scope.search = response;
		})
		.error(function(msg) {
			$scope.search = msg;
		});

	};

});

