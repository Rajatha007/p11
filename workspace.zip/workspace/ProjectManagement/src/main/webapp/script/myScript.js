
function displayRatings()
{
	var ratin = productForm.rating.value;
	document.getElementById('ratings').innerHTML='<b>'+ratin+'</b>';
	}

function displayDiscounts()
{
	var dis = productForm.discount.value;
	document.getElementById('discounts').innerHTML='<b>'+dis+'</b>';
	}

function name()
{
	var n = document.getElementById("na").value;
	document.getElementById("name").value = n;
	}
