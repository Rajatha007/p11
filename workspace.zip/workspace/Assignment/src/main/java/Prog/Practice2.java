package Prog;

public class Practice2 
{
static volatile int j;
public static void main(String[] args) {
	System.out.println(j);
}
}
