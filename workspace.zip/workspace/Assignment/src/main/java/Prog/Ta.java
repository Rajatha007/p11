package Prog;


public class Ta

{

		}


