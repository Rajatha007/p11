package Prog;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DateOfBirth 
{
	private String dtOfBirth;
	public void calAge()
	{
		Date date = new Date();
		System.out.println(date.toString());
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter your date of birth: ");
		dtOfBirth = scn.next();
		
		SimpleDateFormat myFormat = new SimpleDateFormat("dd-mm-yyyy");
		String myDate = myFormat.format(dtOfBirth);
		
	}

}
