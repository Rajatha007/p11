package Prog;

public class Main {

	public static void main(String[] args) 
	{
		DateOfBirth d1 = new DateOfBirth();
		d1.calAge();
	}

}
