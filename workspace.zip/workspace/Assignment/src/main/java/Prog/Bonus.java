package Prog;

public class Bonus {

	public Bonus() {
		// TODO Auto-generated constructor stub
	}

}
