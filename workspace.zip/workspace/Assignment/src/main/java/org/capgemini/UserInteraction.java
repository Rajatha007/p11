package org.capgemini;

import java.util.Date;
import java.util.Scanner;

import org.capg.Emp;
import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;

public class UserInteraction {
	Empl e1 = new Empl();
	int employeeId,age;
	double salary;
	boolean flag=false;
	String eid,empKinId,firstName,lastName,eMail,empDOB,empDOJ;
	private String address;

		
		public Empl getEmployee(){
			
			
			Scanner sc=new Scanner(System.in);
			Validate v1 =  new Validate();
			
			//Validate Employee Id
			/*do{
			System.out.println("Enter Employee Id:");
			eid=sc.next();
			flag=Validate.isValidEmployeeId(eid);
				if(!flag)
					System.out.println("INvalid EmployeeId! ID should be 5 digit!");
			
			}while(!flag);

			e1.setEmpId(Integer.parseInt(eid));*/
			
			
			
					//Validate Employee KinId
					/*do{
					System.out.println("Enter Employee KinId:");
					empKinId=sc.next();
					flag=Validate.isValidKinId(empKinId);
						if(!flag)
							System.out.println("INvalid KinId!");
					
					}while(!flag);

					e1.setKinId(empKinId);*/
					
					
					//Validate First Name
				/*	do{
					System.out.println("Enter First Name:");
					firstName =sc.next();
					flag=Validate.isValidfirstName(firstName);
						if(!flag)
							System.out.println("INvalid First Name!");
		
					}while(!flag);

					e1.setFirstName(firstName);*/

					//Validate Last Name
				/*	do{
						System.out.println("Enter Employee last Name:");
						lastName=sc.next();
						flag=Validate.isValidLastName(lastName);
							if(!flag)
								System.out.println("INvalid Last Name!");
						
					}while(!flag);
			
					e1.setLastName(lastName);*/
					
				//Validate age
				/*	do{
						System.out.println("Enter age:");
						age=sc.nextInt();
						flag=Validate.isValidAge(age);
							if(!flag)
								System.out.println("INvalid age");
						
						}while(!flag);

						e1.setAge(age);*/
						
						
						// Validate Salary
						
							System.out.println("Enter Salary:");
							salary=sc.nextDouble();
							
							v1.isValidSalary(salary);
							e1.setSalary(salary);
							
							
							//Validate Date of birth 
							do{
								System.out.println("Enter Date of Birth:");
								empDOB=sc.next();
								flag=Validate.isValidDOB(empDOB);
										if(!flag)
										System.out.println("Formate is in dd-mm-yyyy");
								
								}while(!flag);

								e1.setEmpDOB(empDOB);
								
								
							//	Validate Date of joins
							
								do{
							System.out.println("Enter Date of Join:");
									empDOJ=sc.next();
									flag=Validate.isValidDOJ(empDOJ);
											if(!flag)
											System.out.println("Formate is in dd-mm-yyyy");
									
									}while(!flag);

									e1.setEmpDOJ(empDOJ);
									
					
								
									//Validate Address
									do{
										System.out.println("Enter Address:");
										address=sc.next();
										flag=Validate.isValidAddress(address);
												if(!flag)
												System.out.println("invalid address");
										
										}while(!flag);
									

										e1.setAddress(address);
										
									//Validate email id
										do{
											System.out.println("Enter email id:");
											eMail=sc.next();
											flag=Validate.isValideMail(eMail);
													if(!flag)
													System.out.println("Invalid Format");
											
											}while(!flag);
										

											e1.seteMail(eMail);
								
							
					
			return e1;
		}
}
