package org.capgemini;

public class Employee 
{
 private int empId;
 private String kinId;
 private String firstName;
 private String lastName;
 private int age;
 public String geteMail() {
	return eMail;
}
public void seteMail(String eMail) {
	this.eMail = eMail;
}
private double salary;
 private String empDOB;
 private String empDOJ;
 private String eMail;
 public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getKinId() {
	return kinId;
}
public void setKinId(String kinId) {
	this.kinId = kinId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getEmpDOB() {
	return empDOB;
}
public void setEmpDOB(String empDOB) {
	this.empDOB = empDOB;
}
public String getEmpDOJ() {
	return empDOJ;
}
public void setEmpDOJ(String empDOJ) {
	this.empDOJ = empDOJ;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
private String address;
@Override
public String toString() 
{
	return "Employee [empId=" + empId + ", kinId=" + kinId + ", firstName=" + firstName + ", lastName=" + lastName
			+ ", age=" + age + ", salary=" + salary + ", empDOB=" + empDOB + ", empDOJ=" + empDOJ + ", address="
			+ address + "]";
}

}
