package org.capgemini;

import java.util.Scanner;

import org.capg.Emp;

public class Main4 {

	public static void main(String[] args) 
	{
		Validate v1 = new Validate();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the sal");
		double salary = sc.nextDouble();
		v1.isValidSalary(salary);		
	}

}
