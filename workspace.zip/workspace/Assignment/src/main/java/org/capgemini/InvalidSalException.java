package org.capgemini;

public class InvalidSalException extends  Throwable
{
	public InvalidSalException()
	{
		super("Error! Invalid Salary!");
	}
	
	public InvalidSalException(String msg){
		super(msg);
	}
}
