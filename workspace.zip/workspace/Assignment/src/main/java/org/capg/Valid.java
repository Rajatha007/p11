package org.capg;

public class Valid {

	public static boolean isValidEmployeeId(String empId){
		return empId.matches("\\d{5}");
	}
	
	public static boolean isValidKinId(String kinid){
		return kinid.matches("\\d{5}_(FS|TS|IN|fs|ts|in)");
	}
	
	public static boolean isValidfirstName(String firstName)
	{
		
		return firstName.matches("[A-Z][a-z]+\\S");
		
	}
	
	public static boolean isValidLastName (String lastName)
	{
		return lastName.matches("[a-zA-Z]+\\S");
	}
	
	public static  boolean isValidAge(int age)
	{
		if(age>18)
		
		return true;
		
		else
			
		return false;
		
			
	}
	
	public static boolean isValidSalary(double salary)
	{
		if(salary>=2000 && salary<=500000)
		{
			return true;
		}
		else
			return false;
	}
	
	public static boolean isValidDOB(String empDOB)
	{
		return empDOB.matches("[0-3][0-9]-(jan|feb|mar|apr|may|jun|july|aug|sep|oct|nov|dec)-"
				+ "[12][7890]\\d{2}");
	}
	
	public static boolean isValidDOJ(String empDOJ)
	{
		return empDOJ.matches("[0-3][0-9]-(jan|feb|mar|apr|may|jun|july|aug|sep|oct|nov|dec)-"
				+ "[12][7890]\\d{2}");
	}
	
	public static boolean isValidAddress(String address)
	{
		return address.matches("[a-zA-Z#,./]+\\S");
	}
	
	public static boolean isValideMail(String eMail)
	{
		return eMail.matches("[a-z@.com]+\\S");
	}
}
