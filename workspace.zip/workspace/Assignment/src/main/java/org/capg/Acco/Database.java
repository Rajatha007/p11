package org.capg.Acco;

public class Database 
{
	static Account[] accountDetails=new Account[100];
}
