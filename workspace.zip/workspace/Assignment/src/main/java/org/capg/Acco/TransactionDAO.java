package org.capg.Acco;

public interface TransactionDAO 
{
	public void saveAccount();
	public void withdraw();
	public void deposit();
}
