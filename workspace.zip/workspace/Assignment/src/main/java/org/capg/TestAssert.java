package org.capg;

public class TestAssert 
{
	@Novel(bookName = "SUNSHINE", authorName = "Christopher" ,  type = "horror")
	
	public static void main(String[] args) 
	{
		Calci cal = new Calci();
		cal.getDetails();
		cal.calBonus();
	}
}
