package org.capg;

import org.capgemini.Empl;
import org.capgemini.UserInteraction;

public class Main3 {

	public static void main(String[] args) 
	{

		UserInter us = new UserInter();
		us.getEmployee();
		System.out.println(us);
	}

}
