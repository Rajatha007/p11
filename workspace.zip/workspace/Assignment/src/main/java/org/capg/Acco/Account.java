package org.capg.Acco;

public class Account {
	private int accountNo;
	private String accountName;
	private String openDate;
	private String accountType;
	private double amount;
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getOpenDate() {
		return openDate;
	}
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Account(int accountNo, String accountName, String openDate, String accountType, double amount) {
		super();
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.openDate = openDate;
		this.accountType = accountType;
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountName=" + accountName + ", openDate=" + openDate
				+ ", accountType=" + accountType + ", amount=" + amount + "]";
	}
	

}
