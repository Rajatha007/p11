package org.capg;

import java.util.Scanner;

public class Calci 
{
	double sal;
	double bonus;
	
	public void getDetails()
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Sal : ");
		sal = scn.nextDouble();
		
	}
	
	public void calBonus()
	{
		bonus = (sal*12)/100;
		
		assert bonus>=10000 : "Bonus Greater than 10000";
		System.out.println("bonus is" + bonus);
	}
}
