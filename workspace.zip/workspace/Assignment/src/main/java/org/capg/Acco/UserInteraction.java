package org.capg.Acco;

import java.util.Scanner;

public class UserInteraction 
{
	public static void main(String[] args) {

		String chs = "";
		do {
			TransactionDAOImpl tr = new TransactionDAOImpl();
			@SuppressWarnings("resource")
			Scanner scn = new Scanner(System.in);
			System.out.println("Enter your choice");
			System.out.println("1:choose for save account");
			System.out.println("2:choose for withdraw account");
			System.out.println("3:choose for deposit account");

			int ch = scn.nextInt();
			switch (ch) {

			case 1:
				tr.saveAccount();
				break;
			case 2:
				tr.withdraw();
				break;
			case 3:
				tr.deposit();
				break;

			}
			System.out.println("Do you want to continue?Y/N");
			chs = scn.next();
		} while (chs.equalsIgnoreCase("Y"));
	}
}
