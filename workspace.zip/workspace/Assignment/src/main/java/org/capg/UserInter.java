package org.capg;
import java.util.Date;
import java.util.Scanner;

import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;

public class UserInter {

		Emp emp1 = new Emp();
		int employeeId,age;
		double salary;
		boolean flag=false;
		String eid,empKinId,firstName,lastName,eMail,empDOB,empDOJ;
		private String address;

			
			public  Emp getEmployee(){
				
				
				Scanner sc=new Scanner(System.in);
				
				
				//Validate Employee Id
				do{
				System.out.println("Enter Employee Id:");
				eid=sc.next();
				flag=Valid.isValidEmployeeId(eid);
					if(!flag)
						System.out.println("INvalid EmployeeId! ID should be 5 digit!");
				
				}while(!flag);

				
				emp1.setEmpId(Integer.parseInt(eid));
				
						//Validate Employee KinId
						do{
						System.out.println("Enter Employee KinId:");
						empKinId=sc.next();
						flag=Valid.isValidKinId(empKinId);
							if(!flag)
								System.out.println("INvalid KinId!");
						
						}while(!flag);

						emp1.setKinId(empKinId);
						
						
						//Validate First Name
						do{
						System.out.println("Enter First Name:");
						firstName =sc.next();
						flag=Valid.isValidfirstName(firstName);
							if(!flag)
								System.out.println("INvalid First Name!");
			
						}while(!flag);

						emp1.setFirstName(firstName);

						//Validate Last Name
						do{
							System.out.println("Enter Employee last Name:");
							lastName=sc.next();
							flag=Valid.isValidLastName(lastName);
								if(!flag)
									System.out.println("INvalid Last Name!");
							
						}while(!flag);
				
						emp1.setLastName(lastName);
						
					//Validate age
						do{
							System.out.println("Enter age:");
							age=sc.nextInt();
							flag=Valid.isValidAge(age);
								if(!flag)
									System.out.println("INvalid age");
							
							}while(!flag);

						emp1.setAge(age);
							
							
							// Validate Salary
							do{
								System.out.println("Enter Salary:");
								salary=sc.nextDouble();
								flag=Valid.isValidSalary(salary);
									if(!flag)
										System.out.println("INvalid Salary");
								
								}while(!flag);

							emp1.setSalary(salary);
								
								//Validate Date of birth 
								do{
									System.out.println("Enter Date of Birth:");
									empDOB=sc.next();
									flag=Valid.isValidDOB(empDOB);
											if(!flag)
											System.out.println("Formate is in dd-mm-yyyy");
									
									}while(!flag);

								emp1.setEmpDOB(empDOB);
									
									
								//	Validate Date of joins
								
									do{
								System.out.println("Enter Date of Join:");
										empDOJ=sc.next();
										flag=Valid.isValidDOJ(empDOJ);
												if(!flag)
												System.out.println("Formate is in dd-mm-yyyy");
										
										}while(!flag);

									emp1.setEmpDOJ(empDOJ);
										
						
									
										//Validate Address
										do{
											System.out.println("Enter Address:");
											address=sc.next();
											flag=Valid.isValidAddress(address);
													if(!flag)
													System.out.println("invalid address");
											
											}while(!flag);
										

										emp1.setAddress(address);
											
										//Validate email id
											do{
												System.out.println("Enter email id:");
												eMail=sc.next();
												flag=Valid.isValideMail(eMail);
														if(!flag)
														System.out.println("Invalid Format");
												
												}while(!flag);
											

											emp1.seteMail(eMail);
									
								
						
				return emp1;
			}

}
