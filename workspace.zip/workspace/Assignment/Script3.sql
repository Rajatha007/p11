--<ScriptOptions statementTerminator=";"/>

ALTER TABLE `database`.`employee` DROP PRIMARY KEY;

ALTER TABLE `database`.`teacher` DROP PRIMARY KEY;

ALTER TABLE `database`.`class` DROP PRIMARY KEY;

DROP TABLE `database`.`payscale`;

DROP TABLE `database`.`teacher`;

DROP TABLE `database`.`employee`;

DROP TABLE `database`.`class`;

CREATE TABLE `database`.`payscale` (
	`Min_limit` INT,
	`Mx_limit` INT,
	`grade` CHAR(1)
) ENGINE=InnoDB;

CREATE TABLE `database`.`teacher` (
	`t_no` INT NOT NULL,
	`f_name` VARCHAR(30) NOT NULL,
	`l_name` VARCHAR(30),
	`salary` INT DEFAULT 3000,
	`supervisor` INT,
	`joiningdate` DATE,
	`birthdate` DATE,
	`title` VARCHAR(50),
	PRIMARY KEY (`t_no`)
) ENGINE=InnoDB;

CREATE TABLE `database`.`employee` (
	`empid` INT NOT NULL,
	`firstname` VARCHAR(50),
	`lastname` VARCHAR(50),
	`salary` DECIMAL(10 , 2),
	PRIMARY KEY (`empid`)
) ENGINE=InnoDB;

CREATE TABLE `database`.`class` (
	`class_no` INT NOT NULL,
	`t_no` INT,
	`room_no` INT NOT NULL,
	PRIMARY KEY (`class_no`)
) ENGINE=InnoDB;

