--<ScriptOptions statementTerminator=";"/>

CREATE TABLE employee (
	empid INT NOT NULL,
	firstname VARCHAR(10),
	lastname VARCHAR(50),
	salary DECIMAL(10 , 2) DEFAULT 2000.00,
	empdop DATE,
	PRIMARY KEY (empid)
) ENGINE=InnoDB;

CREATE UNIQUE INDEX firstname ON employee (firstname ASC);

