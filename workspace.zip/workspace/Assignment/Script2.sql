--<ScriptOptions statementTerminator=";"/>

CREATE TABLE category (
	categoryid INT NOT NULL,
	categoryname VARCHAR(50),
	description VARCHAR(100),
	PRIMARY KEY (categoryid)
) ENGINE=InnoDB;

