--<ScriptOptions statementTerminator=";"/>

CREATE TABLE det (
	empid INT NOT NULL,
	firstname VARCHAR(50),
	lastname VARCHAR(50),
	salary DOUBLE,
	departid INT,
	email VARCHAR(50),
	empdob DATE,
	empdoj DATE,
	qualification VARCHAR(10),
	gender VARCHAR(10),
	address VARCHAR(200),
	PRIMARY KEY (empid)
) ENGINE=InnoDB;

