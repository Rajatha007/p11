package org.capg.accounts;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Acount_DAO_Impl implements Account_DAO
{
    Scanner scn = new Scanner(System.in);
    String name;
	public void createAccount() 
	{
		System.out.println("Enter accountNo");
		int accountNo = scn.nextInt();
		System.out.println("Enter accountName");
		String accountName = scn.next();
		System.out.println("Enter account type ");
		System.out.println("Enter 1. Savings, 2. Salary, 3. Joint 4.Corporate");
		int ch = scn.nextInt();
		{
			if(ch==1)
			{
				 name = "Savings";
			}
			if(ch==2)
			{
				name = "Salary";
			}
			if(ch==3)
			{
				name = "Joint";
			}
			if(ch==4)
			{
				name = "Corporate";
			}
			else
			{
				System.out.println("Invalid input");
			}
		
		}
		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		String openDate = sdf.format(dt);
		System.out.println("Enter the Account Opening date");
		openDate = scn.next();
		System.out.println("Enter amount");
		double amount = scn.nextDouble();
		Address ad = new Address();
		ad.getAdd();
	}

	public void updateAccount()
	{
		
	}

	public void readAccount() {
		// TODO Auto-generated method stub
		
	}

	public void deleteAccount() {
		// TODO Auto-generated method stub
		
	}

	public void viewAllAccount() {
		// TODO Auto-generated method stub
		
	}

}
