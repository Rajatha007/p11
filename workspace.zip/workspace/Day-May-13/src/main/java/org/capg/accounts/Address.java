package org.capg.accounts;

import java.util.Scanner;

public class Address 
{
	public int doorNo;
	public String stName;
	public String city;
	public String state;
	Scanner scn = new Scanner(System.in);
	public void getAdd()
	{
	System.out.println("Enter Door No. #: ");
	int doorNo = scn.nextInt();
	System.out.println("Enter the Street Name : ");
	String stName = scn.next();
	System.out.println("Enter City Name: ");
	String city = scn.next();
	System.out.println("Enter State : ");
	String state = scn.next();
	
	
	}	
	
	
}
