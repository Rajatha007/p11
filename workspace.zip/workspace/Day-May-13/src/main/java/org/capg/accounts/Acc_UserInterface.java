package org.capg.accounts;

public class Acc_UserInterface 
{
	Acount_DAO_Impl a1 = new Acount_DAO_Impl();

	
}
