package org.capg.accounts;

import java.util.Scanner;

public class Account_Det 
{
	private int accountNo;
	private String accountName;
	private double amount;
	Scanner scn = new Scanner(System.in);
	public Address a1;
	
}
