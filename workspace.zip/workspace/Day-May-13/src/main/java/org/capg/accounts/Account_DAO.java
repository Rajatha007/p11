package org.capg.accounts;

public interface Account_DAO 
{
	public void createAccount();
	public void updateAccount();
	public void readAccount();
	public void deleteAccount();
	public void viewAllAccount();
}
