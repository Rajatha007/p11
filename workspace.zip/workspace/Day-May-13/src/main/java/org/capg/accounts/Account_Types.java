package org.capg.accounts;

public enum Account_Types {
	
	SAVINGS, CURRENT, JOINT, SALARY;
	
}
