
public class AccountDetails {

}
