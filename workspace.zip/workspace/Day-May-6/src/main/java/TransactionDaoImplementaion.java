import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class TransactionDaoImplementaion implements Transaction
{
	Scanner scn = new Scanner(System.in);

	static boolean isAccountEmpty() {
		Account[] accountDetails = Repository.accountDetails();
		boolean flag = true;
		for (int i = 0; i < accountDetails.length; i++) {
			if (accountDetails[i] != null) {
				flag = false;
				break;
			}
		}
		return flag;
	}


public void saveAccount() {
	System.out.println("Enter accountNo");
	int accountNo = scn.nextInt();
	System.out.println("Enter accountName");
	String accountName = scn.next();
	Date dt = new Date();
	SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	String openDate = sdf.format(dt);
	System.out.println("Enter accountType");
	String accountType = scn.next();
	System.out.println("Enter amount");
	double amount = scn.nextDouble();
	Account acc = new Account(accountNo, accountName, openDate, accountType, amount);
	Account[] accountDetails = Repository.accountDetails();
	for (int i = 0; i < accountDetails.length; i++) {
		if (accountDetails[i] == null) {
			accountDetails[i] = acc;
			break;
		}

	}
	
}

public void withDrawal() {
	Account[] accountDetails = Repository.accountDetails();
	Account acc = null;
	System.out.println("Give Account Number");
	int accountNo = scn.nextInt();
	boolean flag = false;
	for (int i = 0; i < accountDetails.length; i++) {
		if (accountDetails[i].getAccountNo() == accountNo) {
			flag = true;
			acc = accountDetails[i];
			break;

		}
	}
	if (flag) {
		@SuppressWarnings("resource")
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the withdrawal amount");
		int withdrawAmount = scn.nextInt();
		if (withdrawAmount > 0) {
			if (withdrawAmount < acc.getAmount()) {
				acc.setAmount(acc.getAmount() - withdrawAmount);
				System.out.println("Transaction completed successfully");
				System.out.println(acc.getAmount());
			} else
				System.out.println("Txn not completed");
		} else
			System.out.println("Insufficient Fund");

	}
	
}

public void deposit() {
	Account acc = null;
	Account[] accountDetails = Repository.accountDetails;
	System.out.println("Give Account Number");
	int accountNo = scn.nextInt();
	boolean flag = false;
	for (int i = 0; i < accountDetails.length; i++) {
		if (accountDetails[i].getAccountNo() == accountNo) {
			flag = true;
			acc = accountDetails[i];
			break;

		}
	}
	if (flag) {
		@SuppressWarnings("resource")
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Deposit amount");
		int depositAmount = scn.nextInt();
		if (depositAmount > 0) {
			acc.setAmount(acc.getAmount() + depositAmount);
			System.out.println("Deposit completed successfully");
			System.out.println(acc.getAmount());
		} else
			System.out.println("Txn not completed");
	}

}

	
}
