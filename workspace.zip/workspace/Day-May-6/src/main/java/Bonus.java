import java.util.Scanner;

public class Bonus 
{
	private static String empName;
	private double salary;
	
	public void getEmpDetails()
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Employee Name: ");
		String empName = scn.next();
		System.out.println("Enter the Salary : ");
		double salary = scn.nextInt();
	}
	
	//calculate bonus
	public double calBonus(double sal)
	{
		double bonus;
		if(sal>2000000.00)
		{
			bonus = sal*15/100;
			return bonus;
		}
		else if(sal<=1000000.00 && sal>2000000.00)
		{
			bonus= sal*20/100;
			return bonus;
		}
		if(sal<=500000.00 && sal>1000000.00)
		{
			bonus= sal*25/100;
			return bonus;
		}
		else
		{
			bonus = sal*30/100;
			return bonus;
		}
			
	}

public static void main(String[] args) 
{
	
	Bonus b1 = new Bonus();
	b1.getEmpDetails();
	double bonus=b1.calBonus(b1.salary);	
	System.out.println("The bonus of the Employee " + empName + "is " + bonus);
	
	
}	

}
