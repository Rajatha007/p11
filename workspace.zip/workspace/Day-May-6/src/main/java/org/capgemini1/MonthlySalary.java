package org.capgemini1;

import java.util.Scanner;

public class MonthlySalary extends Employee
{
	private float no_of_days;
	private float wages_per_day;
	@Override
	public double calculateSalary() {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the no of hours : ");
		no_of_days = scn.nextFloat();
		System.out.println("Enter the wages per hour : ");
		wages_per_day = scn.nextFloat();
		float sal = wages_per_day*no_of_days;
		
		return no_of_days + sal;
		
	}

	

}
