package org.capgemini1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		Employee emp =null;
		Scanner scn = new Scanner(System.in);
		
		System.out.println("1. Weekly Salary");
		System.out.println("2. Monthly Salary : ");
		System.out.println("Enter your choice");
		
		int ch = scn.nextInt();
		
		if(ch==1)
		{
			emp = new WeeklySalaryEmployee();
		}
		
		else if(ch==2)
		{
			emp = new MonthlySalary();
		}
		
		else
		{
			System.out.println("Invalid Input");
			System.exit(0);
		}
		
		
		emp.printEmployeeDetails();
		double str = emp.calculateSalary();
		System.out.println(str);
	}

}
