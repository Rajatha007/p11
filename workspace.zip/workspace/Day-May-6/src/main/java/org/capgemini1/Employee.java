package org.capgemini1;

import java.util.Scanner;

public abstract class Employee 
{
	
		private int empId;
		private String firstName;
		private String lastName;
		
		
		public void getEmployeeDetails()
		{
			Scanner scn = new Scanner(System.in);
			System.out.println("Enter the employee ID : ");
			empId= scn.nextInt();
			System.out.println(" Enter the First Name of the Employee : ");
			firstName = scn.next();
			System.out.println(" Enter the Last Name of the Employee : ");
			lastName = scn.next();
			calculateSalary();
		}
		
		public void printEmployeeDetails()
		{
			System.out.println("Employee Id : " + empId);
			System.out.println(" First Name : " + firstName);
			System.out.println(" Last Name : " + lastName);
		}
		
		public abstract double calculateSalary();

	
}
