package org.capgemini1;

import java.io.InputStream;
import java.util.Scanner;

public class WeeklySalaryEmployee extends Employee
{
	private float no_of_hours;
	private float wages_per_hour;
	
	@Override
	public double calculateSalary() 
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the no of hours : ");
		no_of_hours = scn.nextFloat();
		System.out.println("Enter the wages per hour : ");
		wages_per_hour = scn.nextFloat();
		float sal = wages_per_hour*no_of_hours*7;
		
		return no_of_hours + sal;
		
		
	}

	

	




}
