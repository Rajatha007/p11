package org.capgemini2;

public class Employee2 
{
	
	private int empId;
	private String firstName;
	private String lastName;
	private double sal;
	

	public Employee2(int empId, String firstName, String lastName, double sal)
	{
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.sal = sal;
	}
	
	public boolean equals(Object obj)
	{
		Employee2 emp = (Employee2) obj;
		if(this==emp)
		{
			return true;
		}
		else
			if(this.empId==emp.empId)
			{
				if(this.firstName==emp.firstName)
				{
					if(this.lastName==emp.lastName)
					{
						return true;
					}
				}else
				
				return false;
			}
			else
				return false;
		return false;
	}
	public static void main(String[] args) 
	{
		Employee2 e1 = new Employee2(1," tom"," jerry", 1.00);
		Employee2 e2 = new Employee2(12, "tom", "l", 2.00);
		System.out.println(e1.equals(e2));
		System.out.println(e1==e2);
		
	}
	

}
