package org.capgemini2;

import java.util.Scanner;

public class Employee1 
{
	
	private int empId;
	private String firstName;
	private String lastName;
	private double salary;
	private Weekdays holiday;
	
	
	
	public void getDetails()
	{
		Scanner scn =  new Scanner(System.in);
		System.out.println("Enter the employee ID : ");
		empId= scn.nextInt();
		System.out.println(" Enter the First Name of the Employee : ");
		firstName = scn.next();
		System.out.println(" Enter the Last Name of the Employee : ");
		lastName = scn.next();
		System.out.println("Enter the salary : ");
		salary = scn.nextDouble();
		System.out.println("Enter the off day : ");
		System.out.println("1. Sunday");
		System.out.println("2. Monday");
		System.out.println("3. Tuesday");
		System.out.println("4. Wednesday");
		System.out.println("5. Thursday");
		System.out.println("6. Friday");
		System.out.println("7. Saturday");
		int choice = scn.nextInt();
		
		switch(choice)
		{
		case 1 : holiday = Weekdays.SUNDAY;
		break;
		case 2 : holiday = Weekdays.MONDAY;
		break;
		case 3 : holiday = Weekdays.TUESDAY;
		break;
		case 4 : holiday = Weekdays.WEDNESDAY;
		break;
		case 5 : holiday = Weekdays.THURSDAY;
		break;
		case 6 : holiday = Weekdays.FRIDAY;
		break;
		case 7 : holiday = Weekdays.SATURDAY;
		break;
		default : 
			System.out.println(" Invalid Input");
		}
		
	}
	
	public void printDetails()
	{
		System.out.println("Employee Id : " + empId);
		System.out.println(" First Name : " + firstName);
		System.out.println(" Last Name : " + lastName);
		System.out.println("Salary : " + salary);
		System.out.println("Holiday : " + holiday);
	                          
	

}
}