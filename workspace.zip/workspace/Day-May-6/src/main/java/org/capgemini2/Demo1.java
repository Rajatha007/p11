package org.capgemini2;

public class Demo1 
{
public static void main(String[] args) {
	StringBuffer str = new StringBuffer("Tom");
	str.append("");
	System.out.println("Length" + str.length());


}
	 

}
