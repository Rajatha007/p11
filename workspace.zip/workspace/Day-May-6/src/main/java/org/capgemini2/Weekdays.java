package org.capgemini2;

public enum Weekdays 
{
	
	SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY;
		
	


}