package org.capgemini2;

public class MainEnum 
{
	public static void main(String[] args) {
		
	

	Employee1 e1 = new Employee1();
	e1.getDetails();
	e1.printDetails();
	
	
	}
}
