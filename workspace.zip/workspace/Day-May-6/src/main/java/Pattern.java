import java.util.Scanner;

public class Pattern 
{

	int i;
	int j;
	int num;
	
	public void getNumber()
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		num = scn.nextInt();
	}
	
	public void getPattern()
	{
		switch(num)
		{
		case 0 : 
				for (i=0;i<5;i++)
				{
					for (j=0;j<5;j++)
					{
						if(j==0 || j==4 || i==0 || i==4)
						{
							System.out.print("*");
						}
						else
						{
							System.out.print(" ");
						}
						
					}
					System.out.println();
				}
			break;
			
		case 1 : 
			for (i=0;i<5;i++)
			{
				for (j=0;j<5;j++)
				{
					if(j==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
		break;
		
		case 2 : 
			for (i=0;i<5;i++)
			{
				for (j=0;j<5;j++)
				{
					if(i==0 || i==4 || i==2 || i==1 && j==4 || i==3 && j==0)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
		break;
		
		case 3 : 
			for (i=0;i<5;i++)
			{
				for (j=0;j<5;j++)
				{
					if(i==0 || i==4 || i==2 || j==4 )
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
		break;
		
		case 4 : 
			for (i=0;i<5;i++)
			{
				for (j=0;j<5;j++)
				{
					if((j==0 )&& (i==1 ||i==2|| i==0) || j==4 || i==2  )
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
		break;
		
		case 5:
			for (i=0;i<5;i++)
			{
				for (j=0;j<5;j++)
				{
					if(i==0 || i==4 || i==2 || i==1 && j==0 || i==3 && j==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
		break;
		
		case 6:
			for (i=0;i<5;i++)
			{
				for (j=0;j<5;j++)
				{
					if(i==0 || i==4 || i==2 || i==1 && j==0 || (i==3 && j==4 || j==0) )
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
		break;
		
		case 7 :
			for (i=0;i<5;i++)
			{
				for (j=0;j<5;j++)
				{
					if(i==0 || j==4)
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
		break;
		
		case 8 :
			for (i=0;i<5;i++)
			{
				for (j=0;j<5;j++)
				{
					if(i==0 || i==4 || i==2 || (i==1 && j==0 || j==4) || (i==3 && j==4 || j==0) )
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
		break;
		
		case 9 :
			for (i=0;i<5;i++)
			{
				for (j=0;j<5;j++)
				{
					if(i==0 || i==4 || i==2 || (i==1 && j==0 || j==4) || (i==3 && j==4 ) )
					{
						System.out.print("*");
					}
					else
					{
						System.out.print(" ");
					}
					
				}
				System.out.println();
			}
		break;
				
		}
	}
	
	public static void main(String[] args) 
	{
		Pattern p1  =  new Pattern();
		p1.getNumber();
		p1.getPattern();
	}

}
