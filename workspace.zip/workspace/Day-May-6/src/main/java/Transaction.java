
public interface Transaction 
{

	public void saveAccount(Account acr,Account acc[]);
	
	
	public void withDrawal(Account acc,  double amt);
	
	
	public void deposit(Account acc, String accountType, double amt);
	
}
