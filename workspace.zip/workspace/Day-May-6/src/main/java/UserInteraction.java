
public class UserInteraction 
{

	void display(Account acc)
	{
		acc.printAccountDetails(acc);
	}

}
