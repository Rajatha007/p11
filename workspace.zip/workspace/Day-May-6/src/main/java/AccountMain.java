import java.util.Scanner;

public class AccountMain 
{
	public static void main(String[] args) {
		int slotNo=0;
		int choice;
		Scanner sc = new Scanner(System.in);
		Account acc[] = new Account[100];
		Transaction td= new TransactionDaoImplementaion();
		System.out.println("Enter  :\n1. to open an account\n2.To deposit.\n3.To withdraw\n4.View Account");
		for(;;)
		{
			
			choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				Account acc1 = new Account();
				acc1.getAccountDetails();
				td.saveAccount(acc1,acc);
				System.out.println("Account Created ");
				break;
			case 2:System.out.println("Deposit done");
				
				break;
			case 3:
				System.out.println("Enter the withdrawal amount");
				Scanner scn = new Scanner(System.in);
				double amt = scn.nextDouble();
				td.withDrawal(acc, amt);
				
				
				System.out.println("withdraw done");
				
				break;
			case 4:System.out.println("To view Account Details");
			UserInteraction UI = new UserInteraction();
			UI.display(acc[slotNo]);
			break;
			
			default: System.out.println("Invalid Input");
			break;
			}
		}
		
		
		
	}
}
