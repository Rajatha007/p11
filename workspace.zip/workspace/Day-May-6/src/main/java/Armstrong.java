import java.util.Scanner;

public class Armstrong 

{
	int sum=0;
	int temp;
	public void cal()
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int orgno = scn.nextInt();
		temp = orgno;
		while(temp!=0)
		{
			int unit = temp%10;
			sum = sum+unit*unit*unit;
			temp = temp/10;
		}
			if(sum==orgno)
			{
				System.out.println("The given no. is armstrong ");
			}
			
			else
			{
				System.out.println("The given no. is not armstrong");
			}
			
		
	}

	public static void main(String[] args)
	{
		Armstrong a1 = new Armstrong();
		a1.cal();
				
	}
}
