
public class DD 
{
	public static void main(String[] args) {
		
	
String str = "new";
float f = Float.parseFloat(str);
System.out.println(f);
}
}
