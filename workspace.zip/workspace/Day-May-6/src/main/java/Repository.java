
public class Repository {
	static Account[] accountDetails=new Account[100];
}
