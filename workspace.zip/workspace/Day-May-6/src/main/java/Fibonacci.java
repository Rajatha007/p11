import java.util.Scanner;

public class Fibonacci 
{
	static int i = 0;
	static int j = 1;
	static int l;

	public void cal(int count)
	{			
		System.out.println("The Fibonacci Series is : ");
		System.out.print(i + " " +j);
		
		for(int n=2;n<count;++n)
		{
			l=i+j;
			i=j;
			j=l;
			System.out.print(" " +l);
			
		}
	}
	public static void main(String[] args) 
	{
		System.out.println("Enter the no. of series : ");
		Scanner scn = new Scanner(System.in);
		int x = scn.nextInt();
		Fibonacci f1 = new Fibonacci();
		f1.cal(x);
	}
	

}
