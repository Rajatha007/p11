import java.util.LinkedList;
import java.util.*;

public class ConvertNumToWord 
{
	private static int num;
	private int unit;
	private int tenth;
	private int hundrd;
	private int thous;
	private int te;
	
	private static String[] units = {"zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen",
			"fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"};
	
	private static String[] tens = {"","","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"};
	
	
	public void getNumber()
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the 4 digit Number ");
		num = scn.nextInt();
	}
 public void getplaces()
 {
		int temp = num;
		unit = temp%10;
		temp = num/10;
		tenth = temp%10;
		temp = temp/10;
		hundrd = temp%10;
		temp = temp/10;
		thous = temp;
		int te= num%100;
		System.out.println(te);
 }
	
	public String getConversion(int x)
	{
		if(x%1000==0)
		{
			return units[thous] + "thousand " + " only";
		}
		if(x%100==0)
		{
			return units[thous]+ " thousand " + units[hundrd] + " hundred only";
		}
		if(x%10==0)
		{
			return units[thous]+ " thousand " + units[hundrd] + " hundred and " + tens[tenth] + " only";
		}
		
		
		else if(te<20)
		{
			return units[thous]+ " thousand " + units[hundrd] + " hundred and " + tens[tenth] + units[unit] + " only";
		}
		else
		{
			return units[thous]+ " thousand " + units[hundrd] + " hundred and " +  units[te] + " only";
		}
			
	}
	
	
		
	
	public static void main(String[] args) 
	{
		ConvertNumToWord cntw = new ConvertNumToWord ();
		cntw.getNumber();
		cntw.getplaces();
		String str =cntw.getConversion(num);
		System.out.println(str);
	}
	
	
		
	}


