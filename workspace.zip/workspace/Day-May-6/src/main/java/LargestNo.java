import java.util.Scanner;

public class LargestNo 
{
	private int i;
	private int j;
	private int k;
	
	public void getNumbers()
	{
		Scanner scn = new Scanner(System.in);
		 System.out.println("Enter Three nos: ");
		 i = scn.nextInt();
		 j = scn.nextInt();
		 k =scn.nextInt();
		 LargestNo l1 = new LargestNo();
		 int m =l1.find(i, j, k);
		 System.out.println("the largest no is "+ m);
		 scn.close();
	}
	 
 public int find(int n1,int n2, int n3)
 {
	 if(n1>n2 && n1>n3)
	 {
		 return n1;
	 }
	 if(n2>n3 && n2>n1)
	 {
		 return n2;
	 }
	 else
		 return n3;
 }
 
	public static void main(String[] args) 
	{
		LargestNo l2 = new LargestNo();
		 l2.getNumbers();
		 
	}

}
