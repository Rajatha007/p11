
public interface Employee {

}
