package org.cap.demo;

public class Customer 
{
	private int custId;
	private String custName;
	private String email;
	
	
	public Customer() {	}


	public Customer(int custId, String custName, String email) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.email = email;
	}


	public int getCustId() {
		return custId;
	}


	public void setCustId(int custId) {
		this.custId = custId;
	}


	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
